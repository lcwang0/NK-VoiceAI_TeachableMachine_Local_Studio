from __future__ import annotations

import json
import os
import tempfile
import threading
import uuid
from pathlib import Path
from typing import Any, Literal

import numpy as np
from fastapi import (
    BackgroundTasks,
    FastAPI,
    File,
    Form,
    HTTPException,
    Request,
    UploadFile,
)
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .archive import ArchiveError
from .audio_frontend import read_wav_bytes
from .audio_pipeline import feature_from_wav_bytes
from .config import (
    MAX_FILES_PER_REQUEST,
    MAX_UPLOAD_BYTES,
    TEMP_ROOT,
    TOOL_NAME,
    WEB_ROOT,
    ensure_workspace,
    is_audio_like,
    is_multi_label,
)
from .export_service import create_model_export
from .image_pipeline import load_image_for_prediction
from .diagnostics import build_diagnostic_text
from .jobs import JobManager
from .model_runtime import ModelRuntime
from .project_store import ProjectError, ProjectNotFound, ProjectStore
from .runtime_config import public_runtime_info
from .training_dispatch import train_project
from .tflite_export import ExportError
from .training_common import TrainingError
from .utils import safe_identifier
from .yamnet_anomaly_pipeline import score_wav_bytes


class CreateProjectRequest(BaseModel):
    kind: Literal["image", "audio", "abnormal_sound", "known_sound"]
    name: str | None = None


class UpdateProjectRequest(BaseModel):
    name: str | None = None
    settings: dict[str, Any] | None = None


class CreateClassRequest(BaseModel):
    name: str | None = None


class UpdateClassRequest(BaseModel):
    name: str


class TrainRequest(BaseModel):
    options: dict[str, Any] = Field(default_factory=dict)


class ExportRequest(BaseModel):
    formats: list[str] = Field(default_factory=lambda: ["int8"])
    include_c_header: bool = True


async def _read_upload(upload: UploadFile, limit: int = MAX_UPLOAD_BYTES) -> bytes:
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = await upload.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > limit:
            raise HTTPException(status_code=413, detail=f"{upload.filename or 'upload'} exceeds {limit} bytes.")
        chunks.append(chunk)
    return b"".join(chunks)


def create_app(
    *,
    store: ProjectStore | None = None,
    jobs: JobManager | None = None,
    runtime: ModelRuntime | None = None,
) -> FastAPI:
    ensure_workspace()
    store = store or ProjectStore()
    recovered_interrupted_jobs = int(getattr(store, "recovered_interrupted_jobs", 0))
    jobs = jobs or JobManager(max_workers=1)
    runtime = runtime or ModelRuntime()
    export_files: dict[str, tuple[Path, str]] = {}
    export_files_lock = threading.RLock()

    app = FastAPI(
        title=TOOL_NAME,
        version=__version__,
        docs_url="/api/docs",
        redoc_url=None,
    )
    app.state.store = store
    app.state.jobs = jobs

    @app.middleware("http")
    async def disable_frontend_cache(request: Request, call_next):
        response = await call_next(request)
        if request.url.path in {"/", "/index.html", "/app.js", "/style.css"}:
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        return response

    app.state.runtime = runtime
    app.state.export_files = export_files
    app.state.recovered_interrupted_jobs = recovered_interrupted_jobs

    @app.exception_handler(ProjectNotFound)
    async def project_not_found_handler(_, exc: ProjectNotFound):  # noqa: ANN001
        return JSONResponse(status_code=404, content={"detail": str(exc)})

    async def validation_handler(_, exc):  # noqa: ANN001
        return JSONResponse(status_code=400, content={"detail": str(exc)})

    for exception_type in (ProjectError, TrainingError, ExportError, ArchiveError):
        app.add_exception_handler(exception_type, validation_handler)

    def ensure_project_idle(project_id: str) -> None:
        active = jobs.active_for_project(project_id)
        if active and active.get("state") in {"queued", "running"}:
            raise HTTPException(
                status_code=409,
                detail="This project already has a training or export job running.",
            )

    @app.get("/api/health")
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "name": TOOL_NAME,
            "version": __version__,
            "workspace": str(store.projects_root.parent),
            "pid": os.getpid(),
            "recovered_interrupted_jobs": recovered_interrupted_jobs,
            "runtime": public_runtime_info(),
        }

    @app.get("/api/diagnostics/download")
    def download_diagnostics() -> PlainTextResponse:
        text = build_diagnostic_text(store, jobs)
        filename = "TM_Local_Studio_Diagnostic.txt"
        return PlainTextResponse(
            text,
            media_type="text/plain; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    @app.get("/api/projects")
    def list_projects() -> dict[str, Any]:
        return {"projects": store.list_projects()}

    @app.post("/api/projects")
    def create_project(request: CreateProjectRequest) -> dict[str, Any]:
        return store.create_project(request.kind, request.name)

    @app.post("/api/projects/import")
    async def import_project(file: UploadFile = File(...)) -> dict[str, Any]:
        payload = await _read_upload(file, limit=512 * 1024 * 1024)
        with tempfile.NamedTemporaryFile(suffix=".zip", dir=TEMP_ROOT, delete=False) as handle:
            handle.write(payload)
            temp_path = Path(handle.name)
        try:
            return store.import_project_archive(temp_path)
        finally:
            temp_path.unlink(missing_ok=True)

    @app.get("/api/projects/{project_id}")
    def get_project(project_id: str) -> dict[str, Any]:
        project = store.get_project(project_id)
        project["active_job"] = jobs.active_for_project(project_id)
        return project

    @app.patch("/api/projects/{project_id}")
    def update_project(project_id: str, request: UpdateProjectRequest) -> dict[str, Any]:
        ensure_project_idle(project_id)
        changes = request.model_dump(exclude_none=True)
        return store.update_project(project_id, changes)

    @app.delete("/api/projects/{project_id}")
    def delete_project(project_id: str) -> dict[str, Any]:
        ensure_project_idle(project_id)
        project_dir = store.project_dir(project_id)
        runtime.clear_project(project_dir)
        store.delete_project(project_id)
        return {"ok": True}

    @app.post("/api/projects/{project_id}/classes")
    def add_class(project_id: str, request: CreateClassRequest) -> dict[str, Any]:
        ensure_project_idle(project_id)
        return store.add_class(project_id, request.name)

    @app.patch("/api/projects/{project_id}/classes/{class_id}")
    def update_class(project_id: str, class_id: str, request: UpdateClassRequest) -> dict[str, Any]:
        ensure_project_idle(project_id)
        return store.update_class(project_id, class_id, request.model_dump())

    @app.delete("/api/projects/{project_id}/classes/{class_id}")
    def delete_class(project_id: str, class_id: str) -> dict[str, Any]:
        ensure_project_idle(project_id)
        return store.delete_class(project_id, class_id)

    @app.post("/api/projects/{project_id}/classes/{class_id}/images")
    async def add_images(
        project_id: str,
        class_id: str,
        files: list[UploadFile] = File(...),
    ) -> dict[str, Any]:
        ensure_project_idle(project_id)
        if len(files) > MAX_FILES_PER_REQUEST:
            raise HTTPException(status_code=400, detail=f"At most {MAX_FILES_PER_REQUEST} files per request.")
        added = 0
        errors: list[str] = []
        for upload in files:
            try:
                payload = await _read_upload(upload)
                store.add_image_bytes(
                    project_id,
                    class_id,
                    payload,
                    source_name=upload.filename or "image.jpg",
                )
                added += 1
            except Exception as exc:
                errors.append(f"{upload.filename or 'image'}: {exc}")
        return {"added": added, "errors": errors, "project": store.get_project(project_id)}

    @app.post("/api/projects/{project_id}/classes/{class_id}/audio")
    async def add_audio(
        project_id: str,
        class_id: str,
        files: list[UploadFile] = File(...),
        overlap: float = Form(0.0),
        recording_session_id: str | None = Form(None),
        device_label: str | None = Form(None),
        device_id: str | None = Form(None),
        device_settings: str | None = Form(None),
        device_metadata: str | None = Form(None),
    ) -> dict[str, Any]:
        ensure_project_idle(project_id)
        if len(files) > MAX_FILES_PER_REQUEST:
            raise HTTPException(status_code=400, detail=f"At most {MAX_FILES_PER_REQUEST} files per request.")
        added = 0
        errors: list[str] = []
        metadata: dict[str, Any] = {}
        if device_metadata:
            try:
                parsed_metadata = json.loads(device_metadata)
            except json.JSONDecodeError as exc:
                raise HTTPException(
                    status_code=400,
                    detail="device_metadata must be valid JSON.",
                ) from exc
            if not isinstance(parsed_metadata, dict):
                raise HTTPException(
                    status_code=400,
                    detail="device_metadata must be a JSON object.",
                )
            metadata.update(parsed_metadata)
        if device_label:
            metadata["label"] = str(device_label)
        if device_id:
            metadata["device_id"] = str(device_id)
        if device_settings:
            try:
                parsed_settings = json.loads(device_settings)
            except json.JSONDecodeError as exc:
                raise HTTPException(
                    status_code=400,
                    detail="device_settings must be valid JSON.",
                ) from exc
            if not isinstance(parsed_settings, dict):
                raise HTTPException(
                    status_code=400,
                    detail="device_settings must be a JSON object.",
                )
            metadata["track_settings"] = parsed_settings
        for upload in files:
            try:
                payload = await _read_upload(upload)
                samples = store.add_audio_bytes(
                    project_id,
                    class_id,
                    payload,
                    source_name=upload.filename or "audio.wav",
                    overlap=max(0.0, min(0.9, float(overlap))),
                    recording_session_id=recording_session_id,
                    device_metadata=metadata or None,
                )
                added += len(samples)
            except Exception as exc:
                errors.append(f"{upload.filename or 'audio'}: {exc}")
        return {"added": added, "errors": errors, "project": store.get_project(project_id)}

    @app.delete("/api/projects/{project_id}/samples/{sample_id}")
    def delete_sample(project_id: str, sample_id: str) -> dict[str, Any]:
        ensure_project_idle(project_id)
        return store.delete_sample(project_id, sample_id)

    @app.delete("/api/projects/{project_id}/classes/{class_id}/samples")
    def clear_class(project_id: str, class_id: str) -> dict[str, Any]:
        ensure_project_idle(project_id)
        return store.clear_class_samples(project_id, class_id)

    @app.post("/api/projects/{project_id}/train")
    def train(project_id: str, request: TrainRequest) -> dict[str, Any]:
        project = store.get_raw_project(project_id)
        if project.get("kind") == "known_sound" and request.options:
            # Persist the options BEFORE training starts, so Preview and Export cannot
            # later read a different detection threshold than the model was trained and
            # evaluated with. It has to happen here rather than inside the pipeline:
            # once set_training_started() runs, _ensure_editable() blocks settings writes.
            try:
                store.update_project(project_id, {"settings": dict(request.options)})
            except ProjectError as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            project = store.get_raw_project(project_id)

        def task(progress):  # noqa: ANN001
            store.set_training_started(project_id)
            try:
                result = train_project(
                    store,
                    project_id,
                    project["kind"],
                    request.options,
                    progress,
                )
                runtime.clear_project(store.project_dir(project_id))
                saved = store.set_training_result(
                    project_id,
                    report=result["report"],
                    artifacts=result["artifacts"],
                )
                return {"project": saved}
            except Exception as exc:
                store.set_training_failed(project_id, str(exc))
                raise

        try:
            return jobs.submit("train", project_id, task)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/jobs/{job_id}")
    def get_job(job_id: str) -> dict[str, Any]:
        try:
            return jobs.get(job_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="Job not found.") from exc

    def _artifact_for_runtime(project: dict[str, Any], runtime_name: str) -> str:
        artifacts = project.get("training", {}).get("artifacts", {})
        mapping = {
            "keras": "keras",
            "float": "keras",
            "float32": "float32",
            "int8": "int8",
            "uint8": "uint8",
            "dynamic": "dynamic",
        }
        key = mapping.get(runtime_name, "keras")
        filename = artifacts.get(key)
        if not filename:
            raise HTTPException(status_code=409, detail=f"Runtime model is unavailable: {runtime_name}")
        return filename

    def _normalized_runtime_name(runtime_name: str) -> str:
        name = str(runtime_name).strip().lower()
        return "keras" if name in {"keras", "float"} else name

    def _prediction_response(project: dict[str, Any], scores: np.ndarray, runtime_name: str) -> dict[str, Any]:
        values = np.asarray(scores, dtype=np.float32).reshape(-1)
        labels = [item["name"] for item in project["classes"]]
        if len(values) != len(labels):
            raise HTTPException(status_code=500, detail="Model output count does not match project classes.")
        predictions = [
            {"class_name": label, "score": float(max(0.0, min(1.0, score)))}
            for label, score in zip(labels, values)
        ]
        predictions.sort(key=lambda item: item["score"], reverse=True)
        return {
            "runtime": runtime_name,
            # image/audio are softmax kinds, so their scores do sum to 1. known_sound
            # builds its own response because its sigmoid scores do not.
            "multi_label": is_multi_label(project.get("kind")),
            "predictions": predictions,
            "top_class": predictions[0]["class_name"] if predictions else None,
        }

    @app.post("/api/projects/{project_id}/predict/image")
    async def predict_image(
        project_id: str,
        file: UploadFile = File(...),
        runtime_name: str = Form("keras"),
    ) -> dict[str, Any]:
        project = store.get_raw_project(project_id)
        if project["kind"] != "image":
            raise HTTPException(status_code=400, detail="Project is not an image project.")
        if project.get("training", {}).get("state") != "trained":
            raise HTTPException(status_code=409, detail="Train the model first.")
        payload = await _read_upload(file)
        report = project["training"].get("report") or {}
        size = int(report.get("settings", {}).get("image_size", project["settings"].get("image_size", 224)))
        array = load_image_for_prediction(payload, size)
        artifact = _artifact_for_runtime(project, runtime_name)
        scores = runtime.predict(store.project_dir(project_id), artifact, array[np.newaxis, ...])[0]
        return _prediction_response(project, scores, runtime_name)

    @app.post("/api/projects/{project_id}/predict/audio")
    async def predict_audio(
        project_id: str,
        file: UploadFile = File(...),
        runtime_name: str = Form("keras"),
    ) -> dict[str, Any]:
        project = store.get_raw_project(project_id)
        if project["kind"] != "audio":
            raise HTTPException(status_code=400, detail="Project is not an audio project.")
        if project.get("training", {}).get("state") != "trained":
            raise HTTPException(status_code=409, detail="Train the model first.")
        payload = await _read_upload(file)
        report = project["training"].get("report") or {}
        settings = {**project["settings"], **report.get("settings", {})}
        feature = feature_from_wav_bytes(payload, settings)
        artifact = _artifact_for_runtime(project, runtime_name)
        scores = runtime.predict(store.project_dir(project_id), artifact, feature[np.newaxis, ...])[0]
        return _prediction_response(project, scores, runtime_name)

    @app.post("/api/projects/{project_id}/predict/abnormal-sound")
    async def predict_abnormal_sound(
        project_id: str,
        file: UploadFile = File(...),
        runtime_name: str = Form("keras"),
    ) -> dict[str, Any]:
        project = store.get_raw_project(project_id)
        if project.get("kind") != "abnormal_sound":
            raise HTTPException(
                status_code=400,
                detail="Project is not an Abnormal Sound project.",
            )
        if project.get("training", {}).get("state") != "trained":
            raise HTTPException(status_code=409, detail="Train the detector first.")
        payload = await _read_upload(file)
        normalized_runtime = _normalized_runtime_name(runtime_name)
        artifact = _artifact_for_runtime(project, normalized_runtime)
        report = project["training"].get("report") or {}
        settings = {**project.get("settings", {}), **(report.get("settings") or {})}
        return score_wav_bytes(
            project_dir=store.project_dir(project_id),
            artifact_name=artifact,
            runtime_name=normalized_runtime,
            payload=payload,
            settings=settings,
            predict=runtime.predict,
        )

    @app.post("/api/projects/{project_id}/predict/known-sound")
    async def predict_known_sound(
        project_id: str,
        file: UploadFile = File(...),
        runtime_name: str = Form("keras"),
    ) -> dict[str, Any]:
        project = store.get_raw_project(project_id)
        if project.get("kind") != "known_sound":
            raise HTTPException(
                status_code=400, detail="Project is not a Known Sound project."
            )
        if project.get("training", {}).get("state") != "trained":
            raise HTTPException(status_code=409, detail="Train the model first.")
        payload = await _read_upload(file)
        from .known_sound_pipeline import score_wav_bytes as score_known_sound

        return score_known_sound(
            store, project_id, payload, _normalized_runtime_name(runtime_name)
        )

    @app.post("/api/projects/{project_id}/audio-sanity")
    async def audio_sanity_check(
        project_id: str,
        file: UploadFile = File(...),
    ) -> dict[str, Any]:
        """Name what the official YAMNet tagger hears in a just-recorded clip.

        Informational only: it never touches training, thresholds or stored metadata. Its
        job is to catch "the microphone did not record what you thought it did" while the
        user is still standing at the mic. A missing class map disables only this feature.
        """
        project = store.get_raw_project(project_id)
        if not is_audio_like(project.get("kind")):
            raise HTTPException(
                status_code=400, detail="This check is only available for audio projects."
            )
        payload = await _read_upload(file)
        from .known_sound_pipeline import describe_waveform
        from .yamnet_model import YAMNET_ASSET_VERSION, YAMNET_SAMPLE_RATE, YamnetClassMapError

        try:
            _, signal = read_wav_bytes(payload, YAMNET_SAMPLE_RATE)
            top = describe_waveform(signal, top_k=3)
        except YamnetClassMapError as exc:
            return {"available": False, "reason": str(exc), "top": []}
        return {"available": True, "top": top, "asset_version": YAMNET_ASSET_VERSION}

    @app.post("/api/projects/{project_id}/export-model")
    def start_export_model(project_id: str, request: ExportRequest) -> dict[str, Any]:
        ensure_project_idle(project_id)
        project = store.get_raw_project(project_id)
        selected = [item.strip().lower() for item in request.formats if item.strip()]
        if not selected:
            raise HTTPException(status_code=400, detail="Select at least one model format.")
        filename = safe_identifier(project["name"]) + "_TFLite.zip"

        def task(progress):  # noqa: ANN001
            fd, temp_name = tempfile.mkstemp(
                prefix="tm_local_model_", suffix=".zip", dir=TEMP_ROOT
            )
            os.close(fd)
            output = Path(temp_name)
            try:
                result = create_model_export(
                    store=store,
                    project_id=project_id,
                    selected=selected,
                    include_c_header=request.include_c_header,
                    output_zip=output,
                    progress=progress,
                )
                runtime.clear_project(store.project_dir(project_id))
                token = uuid.uuid4().hex
                with export_files_lock:
                    export_files[token] = (output, filename)
                return {
                    "download_url": f"/api/exports/{token}",
                    "filename": filename,
                    "formats": result["formats"],
                    "calibration_samples": result["calibration_samples"],
                    "project": result["project"],
                }
            except Exception:
                output.unlink(missing_ok=True)
                raise

        try:
            return jobs.submit("export", project_id, task)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

    @app.get("/api/exports/{token}")
    def download_export(token: str, background_tasks: BackgroundTasks):
        with export_files_lock:
            item = export_files.pop(token, None)
        if not item:
            raise HTTPException(status_code=404, detail="Export file not found or already downloaded.")
        output, filename = item
        if not output.is_file():
            raise HTTPException(status_code=404, detail="Export file is no longer available.")
        background_tasks.add_task(output.unlink, missing_ok=True)
        return FileResponse(output, media_type="application/zip", filename=filename)

    @app.get("/api/projects/{project_id}/export-project")
    def export_project(project_id: str, background_tasks: BackgroundTasks):
        ensure_project_idle(project_id)
        project = store.get_raw_project(project_id)
        filename = safe_identifier(project["name"]) + "_Project.zip"
        fd, temp_name = tempfile.mkstemp(prefix="tm_local_project_", suffix=".zip", dir=TEMP_ROOT)
        os.close(fd)
        output = Path(temp_name)
        store.export_project_archive(project_id, output)
        background_tasks.add_task(output.unlink, missing_ok=True)
        return FileResponse(output, media_type="application/zip", filename=filename)

    # Project samples are intentionally available only on the local server.
    app.mount("/workspace", StaticFiles(directory=str(store.projects_root.parent)), name="workspace")
    app.mount("/", StaticFiles(directory=str(WEB_ROOT), html=True), name="web")
    return app
