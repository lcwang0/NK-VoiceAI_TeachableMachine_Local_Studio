from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import numpy as np

from .audio_frontend import (
    AudioFrontendConfig,
    config_from_mapping,
    log_mel_spectrogram,
    read_wav_file,
)
from .project_store import ProjectStore
from .training_common import (
    ProgressFn,
    TrainingError,
    class_weight_from_labels,
    history_to_json,
    make_keras_progress_callback,
    save_native_keras_model,
    stratified_path_split,
)
from .utils import utc_now_iso


def _bounded_int(value: Any, minimum: int, maximum: int, fallback: int) -> int:
    try:
        return max(minimum, min(maximum, int(value)))
    except (TypeError, ValueError):
        return fallback


def _bounded_float(value: Any, minimum: float, maximum: float, fallback: float) -> float:
    try:
        return max(minimum, min(maximum, float(value)))
    except (TypeError, ValueError):
        return fallback


def _feature_from_path(path: Path, frontend: AudioFrontendConfig) -> np.ndarray:
    _, signal = read_wav_file(path, frontend.sample_rate)
    return log_mel_spectrogram(signal, frontend)


def _build_audio_model(feature_shape: tuple[int, int, int], class_count: int):
    import tensorflow as tf

    inputs = tf.keras.Input(shape=feature_shape, dtype=tf.float32, name="spectrogram")
    x = tf.keras.layers.Conv2D(16, (3, 3), padding="same", activation="relu", name="conv1")(inputs)
    x = tf.keras.layers.MaxPooling2D((2, 2), name="pool1")(x)
    x = tf.keras.layers.Conv2D(32, (3, 3), padding="same", activation="relu", name="conv2")(x)
    x = tf.keras.layers.MaxPooling2D((2, 2), name="pool2")(x)
    x = tf.keras.layers.Conv2D(64, (3, 3), padding="same", activation="relu", name="conv3")(x)
    x = tf.keras.layers.GlobalAveragePooling2D(name="global_average_pool")(x)
    x = tf.keras.layers.Dropout(0.20, name="dropout")(x)
    outputs = tf.keras.layers.Dense(class_count, activation="softmax", name="scores")(x)
    return tf.keras.Model(inputs, outputs, name="tm_local_audio_classifier")


def _make_dataset(
    features: np.ndarray,
    labels: np.ndarray,
    batch_size: int,
    *,
    training: bool,
):
    import tensorflow as tf

    dataset = tf.data.Dataset.from_tensor_slices((features, labels))
    if training:
        dataset = dataset.shuffle(max(32, len(features)), reshuffle_each_iteration=True)

        def augment(feature, label):  # noqa: ANN001
            max_shift = tf.maximum(1, tf.shape(feature)[0] // 12)
            shift = tf.random.uniform([], -max_shift, max_shift + 1, dtype=tf.int32)
            feature = tf.roll(feature, shift=shift, axis=0)
            gain = tf.random.uniform([], 0.90, 1.10)
            noise = tf.random.normal(tf.shape(feature), stddev=0.012)
            feature = tf.clip_by_value(feature * gain + noise, 0.0, 1.0)
            return feature, label

        dataset = dataset.map(augment, num_parallel_calls=tf.data.AUTOTUNE)
    return dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)


def write_audio_frontend_reference(models_dir: Path) -> None:
    source = r'''from __future__ import annotations

import json
import math
import sys
from functools import lru_cache
from pathlib import Path

import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly


def scale_pcm_dtype(data: np.ndarray, dtype, out_dtype) -> np.ndarray:
    if np.issubdtype(dtype, np.floating):
        return data.astype(out_dtype)
    if dtype == np.uint8:
        return (data.astype(out_dtype) - 128.0) / 128.0
    info = np.iinfo(dtype)
    return data.astype(out_dtype) / float(max(abs(info.min), info.max))


def normalize_pcm(data: np.ndarray) -> np.ndarray:
    data = np.asarray(data)
    if data.ndim == 2:
        # Scale first, mix second -- must stay bit-identical to
        # tm_local/audio_frontend.py:_normalize_pcm(). Averaging raw integer channels
        # first leaves the values on the +-32768 scale, which then satisfies
        # issubdtype(floating), skips the integer rescale and is clipped into a
        # full-scale square wave.
        value = scale_pcm_dtype(data, data.dtype, np.float64).mean(axis=1).astype(np.float32)
    else:
        value = scale_pcm_dtype(data, data.dtype, np.float32)
    return np.clip(np.nan_to_num(value), -1.0, 1.0).astype(np.float32)


def load_wav(path: str | Path, target_rate: int) -> np.ndarray:
    rate, data = wavfile.read(path)
    signal = normalize_pcm(np.asarray(data))
    if rate != target_rate:
        gcd = math.gcd(int(rate), int(target_rate))
        signal = resample_poly(signal, target_rate // gcd, rate // gcd).astype(np.float32)
    return signal


def fix_length(signal: np.ndarray, length: int) -> np.ndarray:
    signal = np.asarray(signal, dtype=np.float32).reshape(-1)
    if signal.size >= length:
        start = max(0, (signal.size - length) // 2)
        return signal[start:start + length]
    output = np.zeros(length, dtype=np.float32)
    start = (length - signal.size) // 2
    output[start:start + signal.size] = signal
    return output


def hz_to_mel(value):
    return 2595.0 * np.log10(1.0 + np.asarray(value, dtype=np.float64) / 700.0)


def mel_to_hz(value):
    return 700.0 * (10.0 ** (np.asarray(value, dtype=np.float64) / 2595.0) - 1.0)


def mel_filterbank(config: dict) -> np.ndarray:
    rate = int(config["sample_rate"])
    fft_size = int(config["fft_size"])
    mel_bins = int(config["mel_bins"])
    points = np.linspace(hz_to_mel(config["fmin"]), hz_to_mel(config["fmax"]), mel_bins + 2)
    bins = np.floor((fft_size + 1) * mel_to_hz(points) / rate).astype(int)
    bins = np.clip(bins, 0, fft_size // 2)
    filters = np.zeros((mel_bins, fft_size // 2 + 1), dtype=np.float32)
    for index in range(1, mel_bins + 1):
        left, center, right = bins[index - 1], bins[index], bins[index + 1]
        center = max(left + 1, center)
        right = max(center + 1, right)
        for position in range(left, min(center, filters.shape[1])):
            filters[index - 1, position] = (position - left) / max(1, center - left)
        for position in range(center, min(right, filters.shape[1])):
            filters[index - 1, position] = (right - position) / max(1, right - center)
    filters /= np.maximum(filters.sum(axis=1, keepdims=True), 1e-12)
    return filters


def extract_feature(path: str | Path, config_path: str | Path | None = None) -> np.ndarray:
    config_path = Path(config_path or Path(__file__).with_name("audio_frontend.json"))
    config = json.loads(config_path.read_text(encoding="utf-8"))
    signal = fix_length(load_wav(path, int(config["sample_rate"])), int(config["clip_samples"]))
    window = int(config["window_samples"])
    hop = int(config["hop_samples"])
    frames = int(config["frame_count"])
    needed = window + (frames - 1) * hop
    signal = np.pad(signal, (0, max(0, needed - signal.size)))
    shape = (frames, window)
    strides = (signal.strides[0] * hop, signal.strides[0])
    framed = np.lib.stride_tricks.as_strided(signal, shape=shape, strides=strides).copy()
    framed *= np.hanning(window).astype(np.float32)[None, :]
    spectrum = np.fft.rfft(framed, n=int(config["fft_size"]), axis=1)
    power = (np.abs(spectrum) ** 2).astype(np.float32)
    mel = power @ mel_filterbank(config).T
    db = 10.0 * np.log10(np.maximum(mel, 1e-10))
    db -= np.max(db)
    floor = float(config["db_floor"])
    normalized = (np.clip(db, floor, 0.0) - floor) / -floor
    return normalized.astype(np.float32)[..., None]


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python audio_frontend_reference.py sample.wav")
    value = extract_feature(sys.argv[1])
    print(value.shape, value.dtype, float(value.min()), float(value.max()))
'''
    (models_dir / "audio_frontend_reference.py").write_text(source, encoding="utf-8")


def write_audio_runner(
    models_dir: Path,
    model_filename: str = "audio_classifier_spectrogram_int8.tflite",
) -> None:
    source = rf'''from pathlib import Path
import sys
import numpy as np
import tensorflow as tf
from audio_frontend_reference import extract_feature

MODEL = Path(__file__).with_name("{model_filename}")
LABELS = [line.split(" ", 1)[1].strip() for line in Path(__file__).with_name("labels.txt").read_text(encoding="utf-8").splitlines() if line.strip()]


def main(path: str) -> None:
    value = extract_feature(path)[None, ...]
    interpreter = tf.lite.Interpreter(model_path=str(MODEL))
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]
    scale, zero = input_detail["quantization"]
    if np.issubdtype(input_detail["dtype"], np.integer):
        info = np.iinfo(input_detail["dtype"])
        value = np.clip(np.round(value / scale + zero), info.min, info.max).astype(input_detail["dtype"])
    interpreter.set_tensor(input_detail["index"], value)
    interpreter.invoke()
    scores = interpreter.get_tensor(output_detail["index"])[0]
    if np.issubdtype(output_detail["dtype"], np.integer):
        out_scale, out_zero = output_detail["quantization"]
        scores = (scores.astype(np.float32) - out_zero) * out_scale
    for label, score in sorted(zip(LABELS, scores), key=lambda item: item[1], reverse=True):
        print(f"{{label}}: {{score:.4f}}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python run_model.py sample.wav")
    main(sys.argv[1])
'''
    (models_dir / "run_model.py").write_text(source, encoding="utf-8")


# Backward-compatible private names used by the test suite and older patches.
_write_audio_frontend_reference = write_audio_frontend_reference
_write_audio_runner = write_audio_runner


def audio_representative_samples(
    store: ProjectStore,
    project_id: str,
    settings: dict[str, Any],
    *,
    limit: int = 120,
) -> list[np.ndarray]:
    """Extract a balanced log-mel representative set for TFLite calibration."""

    frontend = config_from_mapping(settings)
    class_paths = store.sample_paths_by_class(project_id)
    selected: list[Path] = []
    max_count = max((len(paths) for _, paths in class_paths), default=0)
    for offset in range(max_count):
        for _, paths in class_paths:
            if offset < len(paths):
                selected.append(paths[offset])
                if len(selected) >= max(1, int(limit)):
                    return [_feature_from_path(path, frontend) for path in selected]
    return [_feature_from_path(path, frontend) for path in selected]


def train_audio_project(
    store: ProjectStore,
    project_id: str,
    options: dict[str, Any] | None,
    progress: ProgressFn | None = None,
) -> dict[str, Any]:
    options = dict(options or {})
    project = store.get_raw_project(project_id)
    if project["kind"] != "audio":
        raise TrainingError("Project is not an audio project.")
    settings = {**project["settings"], **options}
    frontend = config_from_mapping(settings)
    epochs = _bounded_int(settings.get("epochs"), 1, 300, 40)
    batch_size = _bounded_int(settings.get("batch_size"), 1, 128, 16)
    learning_rate = _bounded_float(settings.get("learning_rate"), 1e-6, 0.1, 0.001)
    validation_split = _bounded_float(settings.get("validation_split"), 0.0, 0.45, 0.2)
    minimum = _bounded_int(settings.get("minimum_samples_per_class"), 2, 200, 8)

    class_paths = store.sample_paths_by_class(project_id)
    shortages = [
        f"{class_item['name']} ({len(paths)}/{minimum})"
        for class_item, paths in class_paths
        if len(paths) < minimum
    ]
    if shortages:
        raise TrainingError("Each class needs more audio samples: " + ", ".join(shortages))
    if progress:
        progress(0.02, "Extracting log-mel spectrograms…")
    split = stratified_path_split(class_paths, validation_split)
    all_paths = split.train_paths + split.validation_paths
    feature_map: dict[Path, np.ndarray] = {}
    for index, path in enumerate(all_paths):
        feature_map[path] = _feature_from_path(path, frontend)
        if progress and (index % 8 == 0 or index + 1 == len(all_paths)):
            progress(0.03 + 0.12 * (index + 1) / max(1, len(all_paths)), f"Audio feature {index + 1}/{len(all_paths)}")
    train_features = np.stack([feature_map[path] for path in split.train_paths]).astype(np.float32)
    train_labels = np.asarray(split.train_labels, dtype=np.int32)
    validation_features = (
        np.stack([feature_map[path] for path in split.validation_paths]).astype(np.float32)
        if split.validation_paths
        else None
    )
    validation_labels = (
        np.asarray(split.validation_labels, dtype=np.int32) if split.validation_paths else None
    )

    import tensorflow as tf

    tf.keras.backend.clear_session()
    tf.keras.utils.set_random_seed(1337)
    model = _build_audio_model(frontend.feature_shape, len(class_paths))
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    train_ds = _make_dataset(train_features, train_labels, batch_size, training=True)
    validation_ds = None
    if validation_features is not None and validation_labels is not None:
        validation_ds = _make_dataset(
            validation_features, validation_labels, batch_size, training=False
        )
    callbacks: list[Any] = [
        make_keras_progress_callback(epochs, progress, start=0.16, end=0.67)
    ]
    monitor = "val_loss" if validation_ds is not None else "loss"
    if bool(settings.get("early_stopping", True)):
        callbacks.append(
            tf.keras.callbacks.EarlyStopping(
                monitor=monitor,
                patience=max(3, min(10, epochs // 4)),
                restore_best_weights=True,
            )
        )
    history = model.fit(
        train_ds,
        validation_data=validation_ds,
        epochs=epochs,
        verbose=0,
        callbacks=callbacks,
        class_weight=class_weight_from_labels(split.train_labels, len(class_paths)),
    )
    evaluation_ds = validation_ds if validation_ds is not None else train_ds
    evaluation = model.evaluate(evaluation_ds, verbose=0, return_dict=True)
    if progress:
        progress(0.69, "Saving trained audio model…")

    project_dir = store.project_dir(project_id)
    models_dir = project_dir / "models"
    if models_dir.exists():
        shutil.rmtree(models_dir)
    models_dir.mkdir(parents=True)
    keras_path = models_dir / "audio_classifier_spectrogram.keras"
    save_native_keras_model(model, keras_path)
    artifacts = {"keras": keras_path.name}
    labels = [item["name"] for item, _ in class_paths]
    (models_dir / "labels.txt").write_text(
        "".join(f"{index} {label}\n" for index, label in enumerate(labels)), encoding="utf-8"
    )
    (models_dir / "audio_frontend.json").write_text(
        json.dumps(frontend.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    write_audio_frontend_reference(models_dir)
    training_report = {
        "project_kind": "audio",
        "trained_at": utc_now_iso(),
        "class_names": labels,
        "class_counts": {item["name"]: len(paths) for item, paths in class_paths},
        "settings": {
            **frontend.to_dict(),
            "epochs_requested": epochs,
            "epochs_completed": len(history.history.get("loss", [])),
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            "validation_split": validation_split,
        },
        "dataset": {
            "train_samples": len(split.train_paths),
            "validation_samples": len(split.validation_paths),
            "calibration_samples": 0,
        },
        "evaluation": {key: float(value) for key, value in evaluation.items()},
        "history": history_to_json(history),
        "conversion": {
            "state": "pending",
            "note": "TensorFlow Lite files are generated only when Export Model is requested.",
        },
    }
    if progress:
        progress(0.96, "Writing audio training report…")
    (models_dir / "training_report.json").write_text(
        json.dumps(training_report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    artifacts.update(
        {
            "training_report": "training_report.json",
            "audio_frontend": "audio_frontend.json",
            "audio_frontend_reference": "audio_frontend_reference.py",
        }
    )
    if progress:
        progress(1.0, "Audio model trained. Preview is ready; use Export Model for INT8 quantization.")
    return {"report": training_report, "artifacts": artifacts}


def feature_from_wav_bytes(payload: bytes, settings: dict[str, Any]) -> np.ndarray:
    from .audio_frontend import read_wav_bytes

    frontend = config_from_mapping(settings)
    _, signal = read_wav_bytes(payload, frontend.sample_rate)
    return log_mel_spectrogram(signal, frontend)
