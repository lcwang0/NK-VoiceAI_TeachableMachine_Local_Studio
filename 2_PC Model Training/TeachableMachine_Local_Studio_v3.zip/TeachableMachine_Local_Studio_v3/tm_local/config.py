from __future__ import annotations

import os
from copy import deepcopy
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_ROOT.parent
WEB_ROOT = PROJECT_ROOT / "web"
DEFAULT_WORKSPACE_ROOT = PROJECT_ROOT / "workspace"
WORKSPACE_ROOT = Path(os.environ.get("TM_LOCAL_WORKSPACE", DEFAULT_WORKSPACE_ROOT)).resolve()
PROJECTS_ROOT = WORKSPACE_ROOT / "projects"
TEMP_ROOT = WORKSPACE_ROOT / "tmp"
LOG_ROOT = PROJECT_ROOT / "logs"
RUNTIME_ROOT = PROJECT_ROOT / "runtime"

TOOL_NAME = "Teachable Machine Local Studio"
TOOL_VERSION = "2.0.7"

MAX_UPLOAD_BYTES = 64 * 1024 * 1024
MAX_FILES_PER_REQUEST = 300
MAX_CLASSES = 20
MAX_CLASS_NAME_LENGTH = 80
MAX_PROJECT_NAME_LENGTH = 120
MAX_PROJECT_ARCHIVE_BYTES = 2 * 1024 * 1024 * 1024

CLASS_COLORS = [
    "#ff6d00",
    "#d83b73",
    "#6b4eff",
    "#1967d2",
    "#00a67e",
    "#a142f4",
    "#e37400",
    "#0b8043",
    "#c5221f",
    "#5f6368",
]

IMAGE_DEFAULTS = {
    "image_size": 224,
    "epochs": 30,
    "batch_size": 16,
    "learning_rate": 0.001,
    "validation_split": 0.20,
    "backbone": "mobilenet_v2",
    "mobilenet_alpha": 0.35,
    "early_stopping": True,
    "minimum_samples_per_class": 5,
}

AUDIO_DEFAULTS = {
    "sample_rate": 16000,
    "clip_seconds": 1.0,
    "window_ms": 25.0,
    "hop_ms": 10.0,
    "fft_size": 512,
    "mel_bins": 40,
    "fmin": 20.0,
    "fmax": 8000.0,
    "db_floor": -80.0,
    "epochs": 40,
    "batch_size": 16,
    "learning_rate": 0.001,
    "validation_split": 0.20,
    "early_stopping": True,
    "minimum_samples_per_class": 8,
}

# --------------------------------------------------------------------------------------
# Abnormal Sound (open-set anomalous sound detection, kind="abnormal_sound")
#
# Trains on NORMAL audio only and scores how far a window deviates from the collected
# normal baseline. It is NOT a classifier and must never name the anomaly.
#
# The locked specification lives in communicate.md; the authoritative sections are
# "[Codex . Round 9]", "[Codex . Round 10]", "[Claude Code . Round 6]" and
# "[Claude Code . Round 7]". Every number below was measured, not guessed -- do not
# "tidy" them without re-running the experiments those sections describe.
# --------------------------------------------------------------------------------------

# Locked model geometry. Dense denoising autoencoder
#   200 -> 128 -> 64 -> 8 -> 64 -> 128 -> 200
# hidden layers Dense(units, activation="relu") with NO BatchNormalization, output layer
# Dense(200, activation="sigmoid"). 69,200 parameters.
# The sigmoid output is load-bearing, not cosmetic: it pins the TFLite int8 output
# quantisation to a fixed scale of exactly 1/256 = 0.00390625, which drops the measured
# quantisation noise floor from 2.002e-04 (linear output) to 2.393e-06 and lifts the score
# margin from 30.5x to 81.9x. Do not switch to a linear output and do not add BatchNorm.
ABNORMAL_SOUND_ENCODER_UNITS = (128, 64)  # decoder mirrors this, then sigmoid Dense(200)
ABNORMAL_SOUND_INPUT_DIM = 200  # context_frames * mel_bins

# T_shape is calibrated separately for every runtime. Measured threshold drift from keras
# to int8 was +70% on the rejected architecture, so this is a hard contract even though the
# accepted sigmoid architecture barely drifts. "keras" is the trained .keras model; the rest
# are the TFLite variants produced by export_service.
ANOMALY_THRESHOLD_RUNTIMES = ("keras", "float32", "dynamic", "int8", "uint8")

# Roles. Exactly one locked "normal_train" container plus 0..MAX_ANOMALY_EVAL_GROUPS
# user-nameable "anomaly_eval" groups. anomaly_eval data is used ONLY for per-group
# evaluation reporting: never for training, threshold calibration, contamination QC
# statistics, or the quantisation representative set.
NORMAL_TRAIN_ROLE = "normal_train"
ANOMALY_EVAL_ROLE = "anomaly_eval"
ABNORMAL_SOUND_ROLES = (NORMAL_TRAIN_ROLE, ANOMALY_EVAL_ROLE)
MAX_ANOMALY_EVAL_GROUPS = MAX_CLASSES - 1

# Train/calibration split. Clips from one recording_session_id NEVER cross the boundary.
# val_sessions = ceil(VAL_SESSION_FRACTION * n_sessions), sessions ordered deterministically
# by sha256(session_id). ceil, never round: round() is banker's rounding, so round(2.5)=2
# while ceil(2.5)=3, and a split that differs between implementations is not reproducible.
# Deliberately a module constant and not a project setting, so the split rule cannot drift
# per project and silently change a calibrated threshold.
VAL_SESSION_FRACTION = 0.25

# Per-branch empirical quantile, taken at 1 - alpha/2 with numpy method="higher".
THRESHOLD_QUANTILE_METHOD = "higher"

ABNORMAL_SOUND_DEFAULTS = {
    # Backend is explicit so an abnormal project can never fall through to the audio
    # classifier. This product workflow is intentionally YAMNet-only; the research Dense
    # AE implementation remains in the source tree as a compact MCU comparison baseline,
    # but is not a partially wired user-selectable backend.
    "detector_backend": "yamnet_embedding",
    # Audio frontend contract. Byte-identical to the first nine AUDIO_DEFAULTS entries:
    # audio_frontend.log_mel_spectrogram() is deliberately UNCHANGED and still yields
    # (98, 40, 1) per 1 s clip. These keys feed audio_frontend.config_from_mapping().
    "sample_rate": 16000,
    "clip_seconds": 1.0,
    "window_ms": 25.0,
    "hop_ms": 10.0,
    "fft_size": 512,
    "mel_bins": 40,
    "fmin": 20.0,
    "fmax": 8000.0,
    "db_floor": -80.0,
    # Shape scorer. 5 consecutive frames are stacked into 200-dim context vectors, giving
    # 98 - 5 + 1 = 94 contexts per clip. S_shape is the arithmetic mean of the LARGEST
    # top_k per-context reconstruction MSEs.
    # top_k and n_contexts are stored as ABSOLUTE INTEGERS and never as a fraction:
    # round(0.10 * 94) = 9 != 10, and letting each language recompute that rounding
    # guarantees PC/MCU divergence.
    "context_frames": 5,
    "n_contexts": 94,
    "top_k": 10,
    # Bottleneck width. Measured equivalent to 16 (margin 78.9x vs 81.9x) while being
    # 1,032 parameters smaller, so 8 is the MVP default. Kept as a named setting -- it is
    # the knob to reach for when the export report warns that the score spread has sunk
    # towards the quantisation noise floor -- but it is NOT exposed in the teaching UI.
    "bottleneck_dim": 8,
    # Autoencoder training. See the notes in the accompanying handover for why these three
    # differ from AUDIO_DEFAULTS: the training items here are 200-dim context vectors
    # (94 per clip), not whole spectrograms, so a clip contributes ~94 rows rather than 1.
    "epochs": 60,
    "batch_size": 64,
    "learning_rate": 0.001,
    # Denoising: train input = clip(x + N(0, denoise_sigma), 0, 1), target = the clean x.
    "denoise_sigma": 0.01,
    # YAMNet one-class scorer. The 3.7M pretrained encoder remains frozen; Train fits these
    # normal-distribution statistics and the held-out threshold from the user's recordings.
    "yamnet_embedding_dim": 1024,
    "yamnet_scorer": "robust_diagonal",
    "yamnet_scale_shrinkage": 0.50,
    "yamnet_scale_floor": 0.0001,
    # Decision policy. See SENSITIVITY_PRESETS for the alpha / vote values.
    "sensitivity": "balanced",
    "hop_seconds": 0.5,
    # Level branch tolerance floor, in dB. T_level = max(empirical quantile, this floor).
    # Without a floor a very stable room drives T_level towards zero and every ordinary
    # loudness wobble alarms.
    "level_tolerance_floor_db": 3.0,
    # Data readiness gates. Below "train" the project refuses to train and says why;
    # between "train" and "calibrated" it is score-only / low confidence and must say so.
    "minimum_train_sessions": 3,
    "minimum_train_seconds": 60,
    "minimum_calibration_sessions": 6,
    "minimum_calibration_seconds": 120,
    "minimum_heldout_sessions": 2,
    "minimum_heldout_clips": 40,
}

# --------------------------------------------------------------------------------------
# Known Sound (closed-set multi-label classifier, kind="known_sound")
#
# Frozen YAMNet 1024-D encoder + a trainable Dense(n_classes, sigmoid) head. Unlike
# abnormal_sound this DOES name the sound, and unlike audio it uses the official YAMNet
# frontend (96 x 64 log-mel patch) rather than the 98 x 40 relative-dB spectrogram.
#
# Multi-label on purpose: two target sounds can occur at once (a dog barking while glass
# breaks), so every class gets an INDEPENDENT sigmoid score. The scores do NOT sum to 1
# and must never be presented as probabilities or as a pie chart.
#
# Design document: docs/superpowers/specs/2026-09-02-known-sound-project-kind-design.md
# --------------------------------------------------------------------------------------

# The head is the only trainable part: embedding_dim * n_classes + n_classes parameters.
# The encoder stays frozen because a few hundred clips cannot fine-tune 3.2M parameters
# without destroying the pretrained representation.
KNOWN_SOUND_EMBEDDING_DIM = 1024  # width at full depth

# How many of YAMNet's 14 blocks to keep. 14 is the full official encoder.
#
# This is the ONLY knob that meaningfully changes the exported model's size, because
# YAMNet is MobileNetV1-shaped and its parameters are heavily back-loaded: block 14 alone
# is ~33% of the encoder, blocks 13-14 together ~49%. Measured on a NuMaker-GestureAI-M55M1
# target (Vela 5.1.0, ethos-u55-256, Shared_Sram, Ethos_U55_High_End_Embedded), post-Vela
# flash for a 3-class head:
#
#   depth 14  2,974,368 B      depth 11  1,308,864 B      depth 8    537,600 B
#   depth 13  2,066,928 B      depth 10  1,051,952 B      depth 7    279,792 B
#   depth 12  1,563,648 B      depth  9    795,680 B      depth 6    144,912 B
#
# Tensor-arena SRAM is ~151 KB at EVERY depth -- the peak activation is in the early
# high-resolution blocks that all depths share -- so depth trades flash, not RAM.
KNOWN_SOUND_DEFAULT_ENCODER_DEPTH = 14
KNOWN_SOUND_MIN_ENCODER_DEPTH = 2
KNOWN_SOUND_MAX_ENCODER_DEPTH = 14

# Validation splits by recording_session_id, never by clip. Clips sliced out of one 20 s
# take are near-duplicates; letting them straddle the boundary is what makes the existing
# audio kind's accuracy look better than it is. Same ceil-not-round rule as
# VAL_SESSION_FRACTION above, and deliberately a module constant so the split rule cannot
# drift per project.
KNOWN_SOUND_VAL_SESSION_FRACTION = 0.25

# Decision threshold for "detected". Per-class overrides live in project settings.
KNOWN_SOUND_DEFAULT_THRESHOLD = 0.5

KNOWN_SOUND_DEFAULTS = {
    # Frozen pretrained encoder. Named explicitly so a known_sound project can never fall
    # through to the from-scratch audio CNN.
    "encoder_backend": "yamnet_embedding",
    # Collection-side audio frontend. Byte-identical to the first nine AUDIO_DEFAULTS
    # entries, for exactly the same reason abnormal_sound copies them: ProjectStore's
    # add_audio_bytes() drives clip slicing and the spectrogram THUMBNAILS through
    # audio_frontend.config_from_mapping(). Without these keys, recording would fail.
    #
    # These are the display/slicing frontend and are NOT what the model eats. The model
    # frontend is the official YAMNet contract (64 mel bins over 125-7500 Hz,
    # log(mel + 0.001), 96 x 64 patch) implemented in tm_local/yamnet_model.py.
    "sample_rate": 16000,
    "clip_seconds": 1.0,
    "window_ms": 25.0,
    "hop_ms": 10.0,
    "fft_size": 512,
    "mel_bins": 40,
    "fmin": 20.0,
    "fmax": 8000.0,
    "db_floor": -80.0,
    # Inference window geometry, matching the collected clip length.
    "hop_seconds": 0.5,
    # How many YAMNet blocks to keep. See the note above; 14 is the full encoder.
    # The embedding width is DERIVED from this, so it is not a separate setting -- the
    # trained value is recorded in the training report under encoder.embedding_dim.
    "encoder_depth": KNOWN_SOUND_DEFAULT_ENCODER_DEPTH,
    # Head training. The head is ~4K parameters on cached embeddings, so a high epoch
    # count still finishes in seconds. The encoder forward pass runs exactly once.
    "epochs": 120,
    "batch_size": 32,
    "learning_rate": 0.001,
    "early_stopping": True,
    # Multi-label decision policy.
    "detection_threshold": KNOWN_SOUND_DEFAULT_THRESHOLD,
    # Preview peak-hold, in seconds. A gunshot lasts 100-200 ms; without a hold the bar
    # spikes and vanishes between frames. This replaces abnormal_sound's 5-window vote,
    # which would actively SUPPRESS a transient event.
    "preview_peak_hold_seconds": 1.5,
    # Mixup augmentation. Two clips from DIFFERENT classes are summed so the model sees
    # genuine simultaneous events, which single-label collection cannot provide.
    # Expressed as a multiple of the training clip count; 0 disables it.
    "mixup_ratio": 0.5,
    # Data readiness gates. Fewer than 2 independent sessions per class makes
    # session-disjoint validation impossible, so the reported accuracy would be
    # meaningless. Train refuses and names exactly what is missing, per class.
    "minimum_sessions_per_class": 2,
    "minimum_clips_per_class": 20,
}

# Sensitivity presets. votes_required out of window_count consecutive 0.5 s-hop windows.
# Sensitive is 2-of-5 on purpose: with a 1 s window and a 0.5 s hop a single point-like
# impact lands in exactly 2 windows, so 3-of-5 can never fire on one knock.
# Fewer than window_count windows since start => UNCERTAIN (warming up), never an alarm.
SENSITIVITY_PRESETS = {
    "sensitive": {"alpha": 0.10, "votes_required": 2, "window_count": 5},
    "balanced": {"alpha": 0.05, "votes_required": 3, "window_count": 5},
    "low_false_alarm": {"alpha": 0.02, "votes_required": 3, "window_count": 5},
}

SENSITIVITY_PRESET_LABELS = {
    "sensitive": "Sensitive",
    "balanced": "Balanced",
    "low_false_alarm": "Low false alarm",
}

DEFAULT_SENSITIVITY = "balanced"

# --------------------------------------------------------------------------------------
# Project kind registry
#
# Dispatch used to be an implicit two-way branch (`if kind == "image" ... else audio`).
# Route new code through these instead so a fourth kind is one entry, not a grep.
# --------------------------------------------------------------------------------------

PROJECT_KINDS = ("image", "audio", "abnormal_sound", "known_sound")

# Kinds whose samples are audio clips and whose settings drive audio_frontend.
# Use this for "does this project record/upload audio", NOT for "is this a classifier":
# abnormal_sound is audio-like but is a one-class detector, not a classifier.
AUDIO_LIKE_KINDS = frozenset({"audio", "abnormal_sound", "known_sound"})

# Kinds that emit one score per project class, i.e. whose model output length must equal
# the class count. This is the contract app._prediction_response() enforces. It is NOT the
# same question as is_audio_like(): abnormal_sound is audio-like but emits a single scalar.
CLASSIFIER_KINDS = frozenset({"image", "audio", "known_sound"})

# Classifier kinds whose per-class scores are INDEPENDENT sigmoids rather than a softmax
# distribution. Scores from these kinds do not sum to 1, so the UI must not show a total.
MULTI_LABEL_KINDS = frozenset({"known_sound"})

DEFAULTS_BY_KIND = {
    "image": IMAGE_DEFAULTS,
    "audio": AUDIO_DEFAULTS,
    "abnormal_sound": ABNORMAL_SOUND_DEFAULTS,
    "known_sound": KNOWN_SOUND_DEFAULTS,
}

PROJECT_KIND_LABELS = {
    "image": "Image Project",
    "audio": "Audio Project",
    "abnormal_sound": "Abnormal Sound Project",
    "known_sound": "Known Sound Project",
}

# Union of every settings key of every kind. This is exactly the drop-in replacement for
# `set(IMAGE_DEFAULTS) | set(AUDIO_DEFAULTS)` in ProjectStore.update_project(): it keeps
# the current behaviour for image/audio byte-for-byte and merely stops abnormal_sound
# settings from being silently discarded. Prefer allowed_setting_keys(kind) when the
# project kind is in hand -- it is strictly tighter.
ALL_SETTING_KEYS = frozenset().union(*(frozenset(values) for values in DEFAULTS_BY_KIND.values()))


def normalize_kind(kind: object) -> str:
    """Canonical spelling of a project kind. Does not validate."""
    return str(kind).strip().lower()


def defaults_for_kind(kind: object) -> dict:
    """Fresh, mutable copy of the default settings for ``kind``.

    Raises ValueError for an unknown kind -- an unknown kind must never fall through to
    the audio defaults the way the old two-way branch did.
    """
    normalized = normalize_kind(kind)
    if normalized not in DEFAULTS_BY_KIND:
        known = ", ".join(PROJECT_KINDS)
        raise ValueError(f"Unknown project kind {normalized!r}. Expected one of: {known}.")
    return deepcopy(DEFAULTS_BY_KIND[normalized])


def is_known_kind(kind: object) -> bool:
    """True when ``kind`` is one of PROJECT_KINDS."""
    return normalize_kind(kind) in DEFAULTS_BY_KIND


def is_audio_like(kind: object) -> bool:
    """True for kinds whose samples are audio clips.

    ``audio``, ``abnormal_sound`` and ``known_sound``. Says nothing about whether the kind
    is a classifier -- use is_classifier() for that.
    """
    return normalize_kind(kind) in AUDIO_LIKE_KINDS


def is_classifier(kind: object) -> bool:
    """True when the model emits one score per project class."""
    return normalize_kind(kind) in CLASSIFIER_KINDS


def is_multi_label(kind: object) -> bool:
    """True when per-class scores are independent sigmoids that do not sum to 1."""
    return normalize_kind(kind) in MULTI_LABEL_KINDS


def allowed_setting_keys(kind: object | None = None) -> frozenset[str]:
    """Settings keys ProjectStore.update_project() should accept.

    With a kind, only that kind's keys (tighter, recommended). Without one, the union over
    every kind, which is the behaviour-preserving drop-in for the current expression.
    """
    if kind is None:
        return ALL_SETTING_KEYS
    normalized = normalize_kind(kind)
    if normalized not in DEFAULTS_BY_KIND:
        known = ", ".join(PROJECT_KINDS)
        raise ValueError(f"Unknown project kind {normalized!r}. Expected one of: {known}.")
    return frozenset(DEFAULTS_BY_KIND[normalized])


def sensitivity_preset(name: object) -> dict:
    """Fresh copy of a sensitivity preset. Raises ValueError for an unknown name."""
    normalized = str(name).strip().lower()
    if normalized not in SENSITIVITY_PRESETS:
        known = ", ".join(SENSITIVITY_PRESETS)
        raise ValueError(f"Unknown sensitivity {normalized!r}. Expected one of: {known}.")
    return dict(SENSITIVITY_PRESETS[normalized])


def abnormal_sound_context_count(settings: dict) -> int:
    """Contexts per clip implied by the frontend geometry: frame_count - context_frames + 1.

    Only for cross-checking the stored absolute ``n_contexts``; the stored integer stays
    the contract so PC and MCU cannot disagree about a rounding.
    """
    from .audio_frontend import config_from_mapping

    frames = config_from_mapping(settings).frame_count
    context_frames = int(settings.get("context_frames", ABNORMAL_SOUND_DEFAULTS["context_frames"]))
    if context_frames < 1:
        raise ValueError("context_frames must be at least 1.")
    if frames < context_frames:
        raise ValueError(
            f"clip_seconds yields only {frames} frames, fewer than context_frames={context_frames}."
        )
    return frames - context_frames + 1


def validate_abnormal_sound_settings(settings: dict) -> dict:
    """Validate an abnormal_sound settings mapping. Returns it unchanged; raises ValueError.

    Call this from ProjectStore wherever ``config_from_mapping`` is already called for the
    audio kind: the frontend keys are validated the same way, plus the scorer invariants
    that would otherwise only surface as a silently wrong score.
    """
    backend = str(settings.get("detector_backend", "yamnet_embedding")).strip().lower()
    if backend != "yamnet_embedding":
        raise ValueError(
            "This Abnormal Sound project supports detector_backend=yamnet_embedding only."
        )
    else:
        if int(settings.get("sample_rate", 0)) != 16000:
            raise ValueError("YAMNet requires mono audio resampled to exactly 16000 Hz.")
        clip_seconds = float(settings.get("clip_seconds", 0.0))
        if clip_seconds != 1.0:
            raise ValueError(
                "This YAMNet workflow requires clip_seconds=1.0 so collection, Train, "
                "Preview, and exported runners use the same window geometry."
            )
        if int(settings.get("yamnet_embedding_dim", 0)) != 1024:
            raise ValueError("This YAMNet backend requires yamnet_embedding_dim=1024.")
        if str(settings.get("yamnet_scorer", "")).strip() != "robust_diagonal":
            raise ValueError("This build implements yamnet_scorer=robust_diagonal.")
        shrinkage = float(settings.get("yamnet_scale_shrinkage", 0.50))
        if not 0.0 <= shrinkage <= 1.0:
            raise ValueError("yamnet_scale_shrinkage must be between 0 and 1.")
        scale_floor = float(settings.get("yamnet_scale_floor", 0.0001))
        if not scale_floor > 0.0:
            raise ValueError("yamnet_scale_floor must be greater than 0.")
    sensitivity_preset(settings.get("sensitivity", DEFAULT_SENSITIVITY))
    hop_seconds = float(settings.get("hop_seconds", ABNORMAL_SOUND_DEFAULTS["hop_seconds"]))
    clip_seconds = float(settings.get("clip_seconds", ABNORMAL_SOUND_DEFAULTS["clip_seconds"]))
    if hop_seconds != 0.5:
        raise ValueError(
            "This YAMNet workflow requires hop_seconds=0.5 so browser and exported "
            "temporal voting use the same window geometry."
        )
    default_floor_db = ABNORMAL_SOUND_DEFAULTS["level_tolerance_floor_db"]
    floor_db = float(settings.get("level_tolerance_floor_db", default_floor_db))
    if floor_db <= 0:
        raise ValueError("level_tolerance_floor_db must be greater than 0.")
    denoise_sigma = float(settings.get("denoise_sigma", ABNORMAL_SOUND_DEFAULTS["denoise_sigma"]))
    if denoise_sigma < 0:
        raise ValueError("denoise_sigma must not be negative.")
    return settings


def validate_known_sound_settings(settings: dict) -> dict:
    """Validate a known_sound settings mapping. Returns it unchanged; raises ValueError.

    The frontend geometry is pinned rather than configurable: collection, Train, Preview
    and the exported runner must all agree with the official YAMNet contract, and a
    project that drifts from it would silently produce embeddings the head never saw.
    """
    backend = str(settings.get("encoder_backend", "yamnet_embedding")).strip().lower()
    if backend != "yamnet_embedding":
        raise ValueError(
            "This Known Sound project supports encoder_backend=yamnet_embedding only."
        )
    if int(settings.get("sample_rate", 0)) != 16000:
        raise ValueError("YAMNet requires mono audio resampled to exactly 16000 Hz.")
    if float(settings.get("clip_seconds", 0.0)) != 1.0:
        raise ValueError(
            "This YAMNet workflow requires clip_seconds=1.0 so collection, Train, "
            "Preview, and exported runners use the same window geometry."
        )
    if float(settings.get("hop_seconds", 0.0)) != 0.5:
        raise ValueError("This YAMNet workflow requires hop_seconds=0.5.")
    depth = int(
        settings.get("encoder_depth", KNOWN_SOUND_DEFAULTS["encoder_depth"])
    )
    if not KNOWN_SOUND_MIN_ENCODER_DEPTH <= depth <= KNOWN_SOUND_MAX_ENCODER_DEPTH:
        raise ValueError(
            f"encoder_depth must be between {KNOWN_SOUND_MIN_ENCODER_DEPTH} and "
            f"{KNOWN_SOUND_MAX_ENCODER_DEPTH}, got {depth}."
        )
    threshold = float(
        settings.get("detection_threshold", KNOWN_SOUND_DEFAULTS["detection_threshold"])
    )
    if not 0.0 < threshold < 1.0:
        raise ValueError("detection_threshold must be strictly between 0 and 1.")
    mixup_ratio = float(settings.get("mixup_ratio", KNOWN_SOUND_DEFAULTS["mixup_ratio"]))
    if mixup_ratio < 0.0:
        raise ValueError("mixup_ratio must not be negative.")
    hold = float(
        settings.get(
            "preview_peak_hold_seconds", KNOWN_SOUND_DEFAULTS["preview_peak_hold_seconds"]
        )
    )
    if hold < 0.0:
        raise ValueError("preview_peak_hold_seconds must not be negative.")
    sessions = int(
        settings.get(
            "minimum_sessions_per_class", KNOWN_SOUND_DEFAULTS["minimum_sessions_per_class"]
        )
    )
    if sessions < 2:
        raise ValueError(
            "minimum_sessions_per_class must be at least 2; session-disjoint validation "
            "is impossible with a single recording session per class."
        )
    clips = int(
        settings.get("minimum_clips_per_class", KNOWN_SOUND_DEFAULTS["minimum_clips_per_class"])
    )
    if clips < 1:
        raise ValueError("minimum_clips_per_class must be at least 1.")
    for key in ("epochs", "batch_size"):
        if int(settings.get(key, KNOWN_SOUND_DEFAULTS[key])) < 1:
            raise ValueError(f"{key} must be at least 1.")
    if float(settings.get("learning_rate", KNOWN_SOUND_DEFAULTS["learning_rate"])) <= 0:
        raise ValueError("learning_rate must be greater than 0.")
    # The collection-side frontend still has to be a valid audio_frontend config, because
    # add_audio_bytes() slices clips and renders thumbnails through it. Imported lazily,
    # matching the other helpers in this module.
    from .audio_frontend import config_from_mapping

    config_from_mapping(settings)
    return settings


def ensure_workspace() -> None:
    PROJECTS_ROOT.mkdir(parents=True, exist_ok=True)
    TEMP_ROOT.mkdir(parents=True, exist_ok=True)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)
