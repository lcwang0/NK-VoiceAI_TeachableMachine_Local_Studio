# v2.0.7 發行說明 — Windows Only

## 新增 Known Sound Project（YAMNet 分類器）

- 新增第四種 `known_sound` project：frozen YAMNet 1024-D encoder + 可訓練的
  `Dense(n, sigmoid)` head，**會說出聽到的是哪一種聲音**（例如槍聲／狗叫／玻璃破裂）。
- **多標籤**：每類一個獨立分數，**不會加總成 100%**，兩種聲音可以同時被偵測到。
  一律稱「信心分數」，不稱「機率」。
- 驗證改為 **session-disjoint**：同一段錄音切出的 clips 永不跨越 train／validation，
  避免既有 Audio Project 的 clip-level leakage 讓 accuracy 虛高。
- 每類至少 2 個獨立錄音場次、20 個片段，不足會擋下訓練並逐類說明還差什麼。
- **混音增強**：訓練時把兩個不同類別的波形相加，讓模型真的學到同時發生的事件。
- Preview 採 **峰值保持**（預設 1.5 秒）而非時間投票——槍聲只持續 100–200 ms，
  投票會抑制正確偵測。
- 匯出為**單一** TFLite（`96×64 log-mel patch → n 個獨立分數`）加 `labels.txt`，
  strict INT8／UINT8 維持零 float tensor、零 Flex、零 custom op，
  並新增以 `detection_agreement` 為主的分類器 parity gate。
- 新增**錄音健檢**：錄音／上傳後用官方 YAMNet 521 類 head 回報 top-3 標籤，
  純資訊性，用來在收資料當下就抓出「錄到的不是你以為的東西」。
- 新增 **`encoder_depth`**（Training 面板可選）：保留 YAMNet 14 個 block 的前 N 個。
  YAMNet 參數嚴重後段集中，因此這是唯一能有效縮小模型的旋鈕 ——
  完整 14 層 Vela 後約 2.97 MB，depth 10 只有約 1.05 MB，可放進 M55M1 的 2 MB 內部 flash。
  tensor arena 在每個深度都約 151 KB，所以換的是 flash 不是 RAM。
  預設仍是 14，既有專案行為完全不變；非完整深度的匯出檔名會帶 `_dN`。
  各深度的實測大小與準確率見 `docs/KNOWN_SOUND_zh-TW.md`。

## 新增 Abnormal Sound Project（YAMNet）

- 新增第三種 `abnormal_sound` project，不會再落入一般 Audio classifier 分支。
- 使用 SHA-256 固定的官方 YAMNet 權重、frozen 1024-D embedding 與 Normal-only scorer。
- `Normal baseline` 依 recording session 分割；`anomaly_eval` 僅評估，禁止進入訓練、threshold 與量化代表資料。
- 新增 GestureAI／DMIC 麥克風選擇、device settings 與 session metadata 保存。
- Preview 顯示 embedding／RMS anomaly ratio，採 5-window temporal vote；未達 calibration gate 時保持 `Uncertain`。
- Export 為每個 Keras／TFLite runtime 分別建立 reference、threshold、實測 FPR confidence 與 SHA binding。
- Strict INT8／UINT8 會重新檢查實際檔案，拒絕 Float、Flex、custom op、錯誤 I/O dtype 或無來源綁定的舊快取。

## 安裝流程簡化

- 移除所有 Linux／WSL GPU 安裝與提示。
- 不會要求重開機後啟動其他作業系統。
- 不會執行 `wsl.exe`、不會安裝 CUDA，也不會建立 Linux virtual environment。
- 只使用 Windows 64-bit CPython 3.13 與專案內 `.venv`。
- Runtime 固定顯示 `Windows CPU`。

## 移除的檔案

```text
requirements-wsl-gpu.txt
scripts/training_worker.py
docs/GPU_SETUP_zh-TW.md
```

## 保留功能

- Image／Audio 資料收集與訓練。
- PC 即時 Preview。
- 清楚的分類百分比和彩色 bar。
- Float32／Dynamic／strict INT8／strict UINT8 TFLite 匯出。
- Train Model 與 Export Model 分離。
- 單一「下載 Log」。
- 根目錄只有 `01_INSTALL.bat` 與 `02_START.bat`。
- Windows BAT 固定使用純 ASCII、CRLF、無 BOM。

## 舊版更新注意

從 v2.0.5／v2.0.6 更新時，可保留：

```text
.venv
workspace
```

重新執行 `01_INSTALL.bat` 後，舊的 GPU runtime 設定會自動覆寫成 Windows CPU，不需要刪除學生專案。
