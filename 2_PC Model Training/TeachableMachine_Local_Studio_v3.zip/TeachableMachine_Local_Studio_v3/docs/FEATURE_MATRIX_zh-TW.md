# 功能矩陣

| 功能 | Image | Audio | Abnormal Sound |
|---|---:|---:|---:|
| Webcam／麥克風收集 | ✅ | ✅ | ✅ |
| 批次上傳樣本 | ✅ | ✅ | ✅ |
| 本機 TensorFlow 訓練 | ✅ | ✅ | ✅（Normal-only scorer） |
| Windows CPU runtime | ✅ | ✅ | ✅ |
| PC 即時 Preview | ✅ | ✅ | ✅（分數＋temporal vote） |
| Float32 TFLite | ✅ | ✅ | ✅ |
| Dynamic Range TFLite | ✅ | ✅ | ✅ |
| Strict INT8 TFLite | ✅ | ✅ | ✅（embedding core） |
| Strict UINT8 TFLite | ✅ | ✅ | ✅（embedding core） |
| C array `model_data.h` | ✅ | ✅ | ✅（仍需 frontend＋scorer） |
| 專案匯出／匯入 | ✅ | ✅ | ✅（匯入後須重訓 threshold） |
| 單一診斷 Log | ✅ | ✅ | ✅ |
| Linux／WSL 安裝 | 不使用 | 不使用 | 不使用 |
| Native Windows NVIDIA training | 本版不提供 | 本版不提供 | 本版不提供 |
