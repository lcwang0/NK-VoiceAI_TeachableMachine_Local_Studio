# Teachable Machine Local Studio v2.0.7 架構

## 整體流程

```text
Chrome / Edge
  ├─ Webcam / microphone capture
  ├─ Sample management
  ├─ Training controls
  ├─ Preview
  └─ Export controls
          │ HTTP 127.0.0.1:8765
          ▼
FastAPI service in Windows .venv
  ├─ ProjectStore
  ├─ Image training pipeline
  ├─ Audio log-mel training pipeline
  ├─ Abnormal Sound frozen-YAMNet pipeline
  ├─ Keras preview runtime
  ├─ TFLite conversion worker
  └─ Diagnostic log builder
          │
          ▼
workspace\projects\<project-id>
  ├─ samples
  ├─ thumbnails
  ├─ project.json
  └─ models
```

## Runtime

v2.0.7 固定使用：

```text
Windows 64-bit CPython 3.13
專案內 .venv
TensorFlow 2.21 Windows CPU runtime
```

`01_INSTALL.bat` 不會建立或呼叫 Linux 環境。`runtime/runtime_config.json` 只會選擇：

```json
{
  "selected_backend": "windows_tensorflow_cpu",
  "backend_label": "Windows CPU",
  "windows_only": true
}
```

為避免較舊教室電腦完全沒有回應，安裝器會依邏輯核心數設定 TensorFlow thread 上限，通常最多使用 8 threads，並在可行時保留一個核心給 Windows。

## Image training

```text
JPEG/PNG/WebP
  → resize / augmentation
  → MobileNetV2 transfer learning 或 small CNN
  → native .keras
  → Preview
```

## Audio training

```text
Browser-decoded mono WAV
  → resample 16 kHz
  → 1-second windows
  → 25 ms framing / 10 ms hop
  → 512-point RFFT
  → 40-bin log-mel spectrogram
  → CNN classifier
  → native .keras
  → Preview
```

## Abnormal Sound training

```text
Browser-decoded mono WAV + recording_session_id
  → resample 16 kHz / one-second stored clips
  → exact 25 ms / 10 ms / 64-mel YAMNet frontend
  → 96 × 64 patch
  → frozen 3,217,344-param YAMNet embedding encoder
  → one 1024-D mean embedding per clip
  → session-balanced robust diagonal Normal reference
  → held-out Normal threshold + independent RMS threshold
  → Keras Preview or per-runtime recalibrated TFLite Preview
```

`normal_train` 與 `anomaly_eval` 是不同資料角色。後者只能產生 evaluation report，
不能進入 reference、threshold、contamination 統計或 representative dataset。同一個
`recording_session_id` 的 clips 不會跨 train／held-out boundary。

Live Preview 每 0.5 秒評估最近一秒，browser 保存最近 5 個 window 並依 sensitivity
做 2-of-5 或 3-of-5 投票。未暖機或 calibration confidence 不足時一律回報
`Uncertain`，仍保留 raw anomaly ratio 供檢查。

## Train／Export 分離

訓練只負責 `.keras`：

```text
fit → evaluate → save .keras → 100% → Preview
```

TFLite 只在 Export 時建立：

```text
.keras
  → explicit SavedModel serving signature
  → separate conversion worker process
  → Float32 / Dynamic / INT8 / UINT8
  → validation and report
  → downloadable ZIP
```

TensorFlow Lite 的單次 `convert()` 沒有 UI 細部進度 callback，因此同一格式轉換期間百分比可能暫時維持不變。主服務會回報經過時間與 worker heartbeat，並在超時時終止 conversion worker；已訓練 `.keras` 與樣本不受影響。

## Log

```text
logs\LATEST_INSTALL.log  最近一次安裝
logs\LATEST.log          最近一次服務／訓練／匯出
```

網頁「下載 Log」將上述資料、Runtime、版本與最近 jobs 整合成一個文字檔，不包含圖片或錄音內容。
