# Known Sound Project（第四種 project kind）設計文件

- 日期：2026-09-02
- 狀態：已與使用者確認，待實作
- 版本基準：Teachable Machine Local Studio v2.0.7 — Windows Only

---

## 1. 背景與動機

使用者要偵測**槍聲、狗叫聲、玻璃破裂聲**，並期望畫面顯示「槍聲 xx%、狗叫 xx%」。

現有的 `abnormal_sound` kind 是 **open-set 異常偵測器**（frozen YAMNet embedding + Normal-only
one-class scorer + RMS branch），它只回答「跟正常差多少」，輸出是一個純量 ratio，**在架構上不可能**
輸出每類百分比。`tm_local/yamnet_anomaly_pipeline.py` 的訓練報告自述：

> `"The detector does not classify or name an anomaly."`

因此需要一個**真正的分類器**。本文件定義第四種 kind：`known_sound`。

### 1.1 一項改變優先順序的實測發現

實作前用官方 YAMNet 521 類 AudioSet head（權重已在 `assets/yamnet/yamnet.h5`，含
`classifier_logits` 與 `class_scores` 兩層）對使用者專案 `a8e2a2a8` 的 123 個錄音做零樣本檢測：

| 資料 | 結果 |
|---|---|
| 61 個 Normal clips | `Silence` 0.59–0.70、`Inside, small room` |
| **62 個 Anomaly Examples** | **62/62 top-1 = `Speech`，分數 0.98–1.00** |
| 目標家族 DOG(69,70,71,72,73,74,75,117) | 最高 0.000，>0.20 者 **0/62** |
| 目標家族 GUN(420–425,430) | 最高 0.001，>0.20 者 **0/62** |
| 目標家族 GLASS(435,436,437,464) | 最高 0.002，>0.20 者 **0/62** |

對照組（已知答案）：白噪音→`White noise` 0.62、440 Hz→`Dial tone` 0.98、數位無聲→`Silence` 1.00，
四項全對，證明 frontend 與權重載入正確。

**結論：使用者收集的「異常樣本」全部是人聲，三種目標聲音一個都沒錄到。**
這直接推導出本設計的 §7「錄音健檢」功能——資料品質問題必須在收集當下就被抓到，而不是訓練完才發現。

---

## 2. 目標與非目標

### 目標

1. 新增 `known_sound` kind：**frozen YAMNet 1024-D encoder + 可訓練 Dense multi-label sigmoid head**。
2. 每類輸出**獨立的 0–100% 信心分數**，支援同時發生的事件。
3. 完整管線：收集 → 訓練 → Preview → 匯出（Keras / Float32 / Dynamic / strict INT8 / strict UINT8）。
4. 沿用 `abnormal_sound` 的收集 UX（麥克風選擇、上傳、長錄音自動切片、session metadata、頻譜縮圖）。
5. 驗證採 **session-disjoint** 切分，杜絕現有 `audio` kind 的 clip-level leakage。
6. 訓練時以**混音增強**造出真正的同時事件樣本。
7. 提供**錄音健檢**：以官方 521 類 head 回報 top-3 標籤，純資訊性。

### 非目標

- 不改寫既有 `image` / `audio` / `abnormal_sound` 的任何語意或 bit-for-bit 行為。
- 不對 MCU 部署做任何承諾。融合模型約 3.5 MiB，定位為 **Desktop / Advanced**。
- 不做 fine-tune YAMNet encoder（小資料下會破壞預訓練表示）。
- 不做真正的多標籤標註 UI（每個 sample 仍屬於單一 class；多標籤能力來自 sigmoid + 混音增強）。

---

## 3. 架構

### 3.1 訓練資料流

```
每個 class 的 1 s clips (16 kHz mono)
  │
  ├─ session-disjoint split：依 recording_session_id 分組，整個 session 只能在
  │  train 或 validation 其中一邊
  │
  ├─ mixup（僅 train 側）：隨機取兩個「不同 class」的 clip，波形相加後正規化，
  │  target = 兩類皆為 1 的 multi-hot
  ↓
YAMNet exact frontend（16 kHz / 25 ms / 10 ms / 512-pt RFFT / 64 mel /
  125–7500 Hz / log(mel+0.001)）→ 96×64 log-mel patch
  ↓
frozen encoder（3,217,344 params，trainable=False，整個訓練期間不更新）
  ↓
1024-D embedding   ← 全資料集只前向一次，快取在記憶體
  ↓
Dense(n_classes, activation="sigmoid")   ← 唯一可訓練層，1024×n + n 個參數
  loss = binary_crossentropy（每類獨立的二元判斷）
```

**設計理由：** encoder 凍結後，每個 clip 的 embedding 是常數。先算完再訓練 head，
可讓 60 個 epoch 的訓練從「60 次 YAMNet 全資料前向」降到「1 次」。以 400 個 clip 估算，
YAMNet 前向約數十秒，head 訓練則是秒級。

### 3.2 推論／匯出

Export 時把 encoder 與 head **融合成單一計算圖**：

```
輸入  float32 / int8  [1, 96, 64]   log-mel patch
出力  float32 / int8  [1, n_classes] 各自獨立的 sigmoid 分數
```

FFT／STFT **不進 flatbuffer**（沿用專案既有決策：frontend 在 host/MCU 端，模型只吃量化後的
log-mel patch）。轉換一律走 `export_inference_saved_model()` + `from_saved_model`，
禁止 `from_keras_model`。

### 3.3 strict INT8 可行性（已驗證）

以 TF 2.10 + 隨機權重跑過 SavedModel → full-integer PTQ：

| | INT8 | UINT8 |
|---|---|---|
| bytes | 3,516,864 | 3,517,168 |
| input / output | int8 / int8 | uint8 / uint8 |
| float tensors | **0** | **0** |
| Flex / custom ops | **NONE** | **NONE** |
| ops | RESHAPE, CONV_2D×14, DEPTHWISE_CONV_2D×13, MEAN, FULLY_CONNECTED, LOGISTIC | 同左 + QUANTIZE×2 |

`FULLY_CONNECTED` 與 `LOGISTIC` 都是 TFLite 內建 int8 op，加上 head 不會破壞既有的
`strict_full_integer` 條件。

> 註：此為 TF 2.10 的可行性證據，非專案規定的 TF 2.21 + tf-keras 證據。實作時必須在
> 專案 `.venv` 重跑並記錄結果。

---

## 4. 輸出語意

1. **分數彼此獨立，不加總為 1。** UI 絕不可顯示總和、圓餅圖或「其餘百分比」。
2. **`Background / Other` 是一個正常類別**，有自己的 bar。放入該類的 clip 會把其他所有類別
   往 0 推，這是抑制誤報的主要機制。
3. **門檻**：預設 0.5，可逐類覆寫。超過門檻的類別在 UI 標示為「偵測到」。
4. **文案**：一律稱「信心分數」，**不得**稱為「機率」。未經 calibration 的 sigmoid 輸出
   在小資料上系統性過度自信。
5. **不做時間投票。** `abnormal_sound` 用 5 窗 3-of-5 投票；槍聲、玻璃破裂只持續 100–200 ms，
   投票會**抑制**正確偵測。Preview 改用**峰值保持（peak-hold）**：每類分數在達到新高後
   維持約 1.5 秒再衰減，讓短暫事件在畫面上留得住。

---

## 5. 資料規則與門檻

### 5.1 Session-disjoint 切分

- 依 `recording_session_id` 分組；**同一個 session 的 clips 永不跨越 train / validation**。
- `project_store.add_audio_bytes()` 已在每個 sample 存了 `recording_session_id`、
  `source_clip_index`、`source_start_sample`、`source_end_sample`、`source_samples`、
  `device_metadata`，**所需 metadata 已經存在**，不需要改資料模型。
- 切分需為決定性（依 `sha256(session_id)` 排序），同一資料集重跑得到同一切分。

### 5.2 訓練門檻（不足則擋下並說明缺什麼）

| 條件 | 值 |
|---|---|
| 類別數 | ≥ 2 |
| 每類獨立 sessions | **≥ 2** |
| 每類 clips | **≥ 20** |

**理由**：少於 2 個 session 就無法做 session-disjoint 驗證，算出來的 accuracy 沒有意義。
擋下時錯誤訊息必須逐類列出「還差幾個 session／幾個 clip」，而不是只說「資料不足」。

### 5.3 混音增強

- 只從 **train** 側的 sessions 取樣，validation 側絕不參與。
- 隨機取兩個不同 class 的 clip，各乘一個隨機增益後相加，必要時正規化避免削波。
- target 為兩類皆 1 的 multi-hot；若其中一類是 `Background`，仍照實標記。
- 生成數量預設為原始 train clip 數的 0.5 倍，可由 settings 調整（0 表示關閉）。
- 混音樣本**不寫入 workspace**，僅存在於訓練過程中。

### 5.4 失效規則

沿用既有 `ProjectStore._invalidate_training()`：任何樣本增刪、class 變更、settings 變更
都會清空 `training` 並 `rmtree` 整個 `models/`。

---

## 6. 檔案異動

### 新增

| 檔案 | 用途 |
|---|---|
| `tm_local/known_sound_pipeline.py` | 訓練、預測、SavedModel 匯出、驗證報告 |
| `assets/yamnet/yamnet_class_map.csv` | 官方 521 類標籤表，SHA-256 pin，供錄音健檢用 |
| `tests/test_known_sound.py` | 本 kind 的單元與整合測試 |

### 修改

| 檔案 | 異動 |
|---|---|
| `tm_local/config.py` | 新增 `KNOWN_SOUND_DEFAULTS`；註冊到 `PROJECT_KINDS`、`AUDIO_LIKE_KINDS`、`DEFAULTS_BY_KIND`、`PROJECT_KIND_LABELS`；新增 `validate_known_sound_settings()` |
| `tm_local/project_store.py` | `create_project()` 接受新 kind；預設類別 `Class 1` / `Class 2` / `Background`（皆可改名增刪）；role 模型為「全部平等」，無 locked 容器 |
| `tm_local/app.py` | `CreateProjectRequest.kind` 的 `Literal`；`POST /predict/known-sound`；`_prediction_response()` 增加多標籤欄位；`POST /audio-sanity` |
| `tm_local/training_dispatch.py` | 依 kind 路由到 `known_sound_pipeline` |
| `tm_local/export_service.py` | `_filename()` prefix、`_representative_samples()` 分支、runner 產生器分支、ZIP 內容（含 `labels.txt`） |
| `tm_local/tflite_export.py` | 新增 classifier comparator（見 §8） |
| `tm_local/yamnet_model.py` | 新增 `load_class_map()` 與官方 head 推論輔助函式（供健檢用） |
| `web/index.html` | 首頁 `data-create-kind` 卡片 |
| `web/app.js` | capture panel、training options、multi-label preview pane、上傳 accept、健檢顯示 |
| `tests/test_distribution.py` | 更新架構護欄斷言 |
| `01_INSTALL.bat` | 下載並驗證 `yamnet_class_map.csv` |
| `PROJECT_MANIFEST_SHA256.txt` | 重新產生（新增檔案） |
| `CLAUDE.md` | 「新增一種 project kind」章節已過時（仍寫 kind 只有 image/audio），需更新為四種並指向 kind registry |

---

## 7. 錄音健檢（Recording Sanity Check）

### 端點

`POST /api/projects/{project_id}/audio-sanity`，body 為一段 WAV。

回傳：

```json
{
  "top": [
    {"index": 0,   "name": "Speech",             "score": 0.994},
    {"index": 500, "name": "Inside, small room", "score": 0.005},
    {"index": 494, "name": "Silence",            "score": 0.002}
  ],
  "asset_version": "audioset-yamnet-h5-13c3308955bb"
}
```

### 規則

- 使用官方 521 類 head（`build_yamnet_models()` 回傳的 `full_model`），**只讀不訓練**。
- **絕對不可**影響訓練、門檻、representative set 或任何已存的 metadata。
- 前端在錄音／上傳完成後顯示一行提示，例如
  「這段聽起來像：Speech 99% · Inside, small room 1%」。
- `yamnet_class_map.csv` 缺檔或 SHA 不符時，健檢功能停用並顯示明確訊息，
  **不得**影響其他功能。

### 為何值得做

它能在使用者花數小時收集資料**之前**，抓出「錄到的不是你以為的東西」。
§1.1 的實測顯示這正是目前發生的事，而現有 anomaly pipeline 只回報一個純量 ratio，
結構上不可能發現這件事（62/62 反而讓人以為一切正常）。

---

## 8. 匯出與驗證

### 8.1 轉換

- 沿用既有隔離子行程：`subprocess.Popen([sys.executable, "-m", "tm_local.conversion_worker", spec.json])`。
- 一律 `export_inference_saved_model()` 寫出明確 `serving_default` signature 後
  `from_saved_model`。禁止 `from_keras_model`。
- representative dataset **只取 train 側 sessions** 的 log-mel patches，
  不得接觸 validation 資料。

### 8.2 嚴格整數要求（硬性）

INT8 / UINT8 產物必須通過 `inspect_tflite()`：integer I/O、零 float tensor、
零 Flex op、零 custom op。不成立即 `raise ExportError`，不得降級交付。

### 8.3 Classifier comparator（取代 embedding cosine 版本）

`abnormal_sound` 比較的是 embedding cosine；分類器需要不同的判準。新增比較項：

| 指標 | 門檻 |
|---|---|
| 每類分數平均絕對誤差（float vs 量化） | ≤ 0.05 |
| 每類分數最大絕對誤差 | ≤ 0.15 |
| 在門檻 0.5 下的偵測決策一致率 | ≥ 0.95 |
| 輸出飽和率（分數恰為 0 或 1 的比例）異常升高 | 需記錄並警告 |

不符即 `ExportError`。

### 8.4 ZIP 內容

選定模型、`labels.txt`（每行一個 class 名稱，順序即輸出順序）、
`yamnet_frontend.json`、frontend 參考實作、PC 端 runner、訓練與轉換報告、metadata。
缺任一必要檔案時 ZIP 直接失敗，不靜默省略。

---

## 9. 錯誤處理

- 沿用 `ProjectError` / `TrainingError` / `ExportError` → `app.py` 對應到 HTTP 400。
- 訓練門檻不足：`TrainingError`，訊息逐類列出缺少的 session 數與 clip 數。
- YAMNet 權重或 class map 缺失／SHA 不符：明確訊息要求重跑 `01_INSTALL.bat`，
  並保證既有錄音不受影響。
- 訓練中的專案由既有 `_ensure_editable()` 擋住編輯。

---

## 10. 測試計畫

`tests/test_known_sound.py`：

1. **kind 註冊**：`known_sound` 出現在 `PROJECT_KINDS`、`AUDIO_LIKE_KINDS`、
   `DEFAULTS_BY_KIND`、`PROJECT_KIND_LABELS`；`defaults_for_kind("known_sound")` 可用；
   未知 kind 仍 raise。
2. **session-disjoint 切分**：構造多 session 資料，斷言沒有任何 session 同時出現在
   train 與 validation；同輸入重跑得到同切分。
3. **訓練門檻**：每類 1 個 session 或 < 20 clips 時 raise `TrainingError`，
   且訊息包含缺少的數量。
4. **混音增強**：target 為 multi-hot（兩類皆 1）；混音只取自 train 側。
5. **head 形狀與啟動函數**：`Dense(n, sigmoid)`；encoder `trainable is False`；
   可訓練參數數 == `1024*n + n`。
6. **多標籤預測回應**：輸出長度 == class 數；分數不強制加總為 1；
   `detected` 欄位正確反映門檻。
7. **健檢端點**：回傳 top-3；class map 缺失時優雅停用且不影響其他端點。
8. **失效規則**：新增樣本後 `training` 被清空、`models/` 被移除。

`tests/test_distribution.py` 需新增／更新的護欄斷言：

- `PROJECT_KINDS` 含四種 kind。
- `known_sound_pipeline.py` 內不得出現 `from_keras_model(`。
- Train 只產生 `.keras`；pipeline 內不得出現 `convert_all(`。
- `web/app.js` 含 known_sound 專用的 DOM／函式名稱。
- 仍只有兩個 BAT，且為 ASCII + CRLF 無 BOM。
- 原始碼不得出現 `wsl.exe`、`nvidia-smi`、`tensorflow[and-cuda]`。

端到端（需 `.venv`）：以合成音訊建立多 session 專案 → Train → Preview → 匯出 strict INT8 →
執行 ZIP 內 runner，斷言分數與 Keras 一致（依 §8.3 門檻）。

---

## 11. 已知限制（必須誠實揭露）

1. **訓練資料是單標籤。** 每個 sample 只屬於一個 class；多標籤能力來自 sigmoid 與混音增強，
   不等同於在真實混合音訊上訓練。
2. **約 3.5 MiB。** 定位 Desktop／Advanced。strict INT8 通過 ≠ 任意 MCU 可跑；
   未指定板子的 flash、SRAM arena、op resolver 與 latency 前，不得使用「可上 MCU」字眼。
3. **每 patch 約 68.9 M MACs。**
4. **分數未經 calibration**，不是真實機率。
5. **喇叭播放的 domain gap**：用喇叭播出來再錄的聲音，模型可能學到「喇叭在響」而非事件本身。
   UI 應提示使用者混合不同音量／距離／位置，並盡量加入真實錄音檔。
6. **驗證成績僅代表「這支麥克風、這個房間、這種播放方式」下的成績。**

---

## 12. 待實作時決定的細項

以下不影響架構，實作時依現有慣例決定即可：

- `KNOWN_SOUND_DEFAULTS` 中 epochs / batch_size / learning_rate 的實際數值
  （head 極小，預期 epochs 可設較高而仍為秒級）。
- Preview peak-hold 的衰減時間常數（起始建議 1.5 秒）。
- 混音增強比例的預設值（起始建議 0.5）。
