'use strict';

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

const PROJECT_KIND_META = Object.freeze({
  image: { label: 'Image', icon: '▧' },
  audio: { label: 'Audio', icon: '≋' },
  abnormal_sound: { label: 'Abnormal Sound', icon: '⌁!' },
  known_sound: { label: 'Known Sound', icon: '♪?' },
});

const NORMAL_TRAIN_ROLE = 'normal_train';
const ANOMALY_EVAL_ROLE = 'anomaly_eval';
const SYSTEM_DEFAULT_MICROPHONE = '__system_default__';

const state = {
  projects: [],
  project: null,
  activePanel: null,
  jobTimer: null,
  activeJobId: null,
  exportJobTimer: null,
  activeExportJobId: null,
  exportStartedAt: 0,
  cameraStream: null,
  imageCaptureTimer: null,
  imageCaptureBlobs: [],
  imageCaptureStartedAt: 0,
  imageCaptureClassId: null,
  audioStream: null,
  audioContext: null,
  audioSource: null,
  audioProcessor: null,
  audioAnalyser: null,
  audioSilentGain: null,
  audioRecording: false,
  audioRecordedChunks: [],
  audioRecordStartedAt: 0,
  audioRecordTimer: null,
  audioRecordingClassId: null,
  audioRecordingSessionId: null,
  audioDeviceId: '',
  audioDevices: [],
  audioTrackSettings: null,
  microphoneRefreshBusy: false,
  audioRollingChunks: [],
  audioRollingSamples: 0,
  audioAnimation: null,
  previewTimer: null,
  previewBusy: false,
  previewSessionId: null,
  abnormalPreviewVotes: [],
  previewImageFile: null,
  confirmResolver: null,
};

const elements = {
  homeView: $('#homeView'),
  projectView: $('#projectView'),
  projectHeaderTools: $('#projectHeaderTools'),
  projectNameInput: $('#projectNameInput'),
  saveState: $('#saveState'),
  recentProjects: $('#recentProjects'),
  emptyProjects: $('#emptyProjects'),
  classStack: $('#classStack'),
  projectKindBadge: $('#projectKindBadge'),
  projectSampleSummary: $('#projectSampleSummary'),
  trainingIdle: $('#trainingIdle'),
  trainingProgress: $('#trainingProgress'),
  trainingDone: $('#trainingDone'),
  trainingHint: $('#trainingHint'),
  trainingMessage: $('#trainingMessage'),
  trainingPercent: $('#trainingPercent'),
  trainingProgressBar: $('#trainingProgressBar'),
  trainingAccuracy: $('#trainingAccuracy'),
  trainingOptions: $('#trainingOptions'),
  trainButton: $('#trainButton'),
  openExportButton: $('#openExportButton'),
  previewLocked: $('#previewLocked'),
  previewReady: $('#previewReady'),
  imagePreviewPane: $('#imagePreviewPane'),
  audioPreviewPane: $('#audioPreviewPane'),
  predictionBars: $('#predictionBars'),
  predictionNote: $('#predictionNote'),
  previewInputToggle: $('#previewInputToggle'),
  previewToggleText: $('#previewToggleText'),
  previewRuntime: $('#previewRuntime'),
  previewVideo: $('#previewVideo'),
  previewCanvas: $('#previewCanvas'),
  liveSpectrogramCanvas: $('#liveSpectrogramCanvas'),
  audioLiveText: $('#audioLiveText'),
  microphoneDeviceControls: $('#microphoneDeviceControls'),
  microphoneDeviceSelect: $('#microphoneDeviceSelect'),
  microphoneTrackSettings: $('#microphoneTrackSettings'),
  connectorSvg: $('#connectorSvg'),
  busyOverlay: $('#busyOverlay'),
  busyText: $('#busyText'),
  toastRegion: $('#toastRegion'),
};

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatDate(value) {
  try {
    return new Intl.DateTimeFormat('zh-TW', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
  } catch (_) {
    return value || '';
  }
}

function formatPercent(value) {
  const percent = Math.max(0, Math.min(1, Number(value) || 0)) * 100;
  if (percent >= 99.95) return '100%';
  if (percent <= 0) return '0%';
  if (percent < 0.05) return '<0.1%';
  return `${percent.toFixed(1)}%`;
}

function projectKindMeta(kind) {
  return PROJECT_KIND_META[kind] || { label: String(kind || 'Project'), icon: '?' };
}

function isAbnormalSoundProject(project = state.project) {
  return project?.kind === 'abnormal_sound';
}

function isKnownSoundProject(project = state.project) {
  return project?.kind === 'known_sound';
}

function isAudioLikeProject(project = state.project) {
  return project?.kind === 'audio' || project?.kind === 'abnormal_sound' || project?.kind === 'known_sound';
}

// Known Sound scores are independent sigmoids, so several classes can be "detected" at
// once and the bars deliberately do not add up to 100%.
function knownSoundThreshold(project = state.project) {
  const fromReport = Number(project?.training?.report?.settings?.detection_threshold);
  if (Number.isFinite(fromReport) && fromReport > 0 && fromReport < 1) return fromReport;
  const fromSettings = Number(project?.settings?.detection_threshold);
  return Number.isFinite(fromSettings) && fromSettings > 0 && fromSettings < 1 ? fromSettings : 0.5;
}

function knownSoundPeakHoldMs(project = state.project) {
  const seconds = Number(project?.settings?.preview_peak_hold_seconds);
  return (Number.isFinite(seconds) && seconds >= 0 ? seconds : 1.5) * 1000;
}

// A gunshot lasts 100-200 ms. Without a hold the bar spikes between animation frames and
// the user never sees it, so each class keeps its highest recent score for a short while.
function applyKnownSoundPeakHold(predictions) {
  const now = Date.now();
  const holdMs = knownSoundPeakHoldMs();
  const held = state.knownSoundPeaks || (state.knownSoundPeaks = new Map());
  const output = [];
  for (const item of predictions || []) {
    const name = item.class_name;
    const score = Math.max(0, Math.min(1, Number(item.score) || 0));
    const previous = held.get(name);
    if (previous && previous.score > score && now - previous.at < holdMs) {
      output.push({ ...item, score: previous.score, held: true });
      continue;
    }
    held.set(name, { score, at: now });
    output.push({ ...item, score, held: false });
  }
  return output;
}

function projectClassRole(classItem, index = 0, project = state.project) {
  if (!isAbnormalSoundProject(project)) return '';
  const role = String(classItem?.role || '').trim().toLowerCase();
  if (role === NORMAL_TRAIN_ROLE || role === ANOMALY_EVAL_ROLE) return role;
  return index === 0 ? NORMAL_TRAIN_ROLE : ANOMALY_EVAL_ROLE;
}

function normalTrainingClass(project = state.project) {
  if (!isAbnormalSoundProject(project)) return null;
  return project.classes?.find((item, index) => projectClassRole(item, index, project) === NORMAL_TRAIN_ROLE) || null;
}

function classSessionCount(classItem) {
  const explicit = Number(classItem?.recording_session_count ?? classItem?.session_count);
  if (Number.isFinite(explicit) && explicit >= 0) return explicit;
  const keys = new Set();
  for (const sample of classItem?.samples || []) {
    const key = sample.recording_session_id || sample.session_id || sample.source_name;
    if (key) keys.add(String(key));
  }
  return keys.size;
}

function abnormalTrainingReadiness(project = state.project) {
  const normal = normalTrainingClass(project);
  const settings = project?.settings || {};
  const server = project?.abnormal_readiness || project?.data_readiness || {};
  const clips = Number(server.normal_clips ?? normal?.sample_count ?? 0);
  const clipSeconds = Math.max(0.1, Number(settings.clip_seconds || 1));
  const seconds = Number(server.normal_seconds ?? normal?.duration_seconds ?? normal?.total_duration_seconds ?? clips * clipSeconds);
  const sessions = Number(server.normal_sessions ?? classSessionCount(normal));
  const minimumSeconds = Math.max(clipSeconds, Number(server.minimum_train_seconds ?? settings.minimum_train_seconds ?? clipSeconds));
  const minimumSessions = Math.max(1, Number(server.minimum_train_sessions ?? settings.minimum_train_sessions ?? 1));
  const calibrationSeconds = Math.max(minimumSeconds, Number(
    server.minimum_calibration_seconds ?? settings.minimum_calibration_seconds ?? minimumSeconds,
  ));
  const calibrationSessions = Math.max(minimumSessions, Number(
    server.minimum_calibration_sessions ?? settings.minimum_calibration_sessions ?? minimumSessions,
  ));
  const serverReady = server.can_train;
  const ready = typeof serverReady === 'boolean'
    ? serverReady
    : Boolean(normal && clips > 0 && seconds >= minimumSeconds && sessions >= minimumSessions);
  const calibrationCandidate = typeof server.calibration_candidate === 'boolean'
    ? server.calibration_candidate
    : seconds >= calibrationSeconds && sessions >= calibrationSessions;
  return {
    normal, clips, seconds, sessions, minimumSeconds, minimumSessions, ready,
    calibrationSeconds, calibrationSessions, calibrationCandidate, note: String(server.note || ''),
  };
}

function newRecordingSessionId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `session-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function readSavedMicrophoneId() {
  try {
    const value = localStorage.getItem('tm-local-microphone-device-id');
    return value === SYSTEM_DEFAULT_MICROPHONE ? '' : (value || '');
  }
  catch (_) { return ''; }
}

function hasSavedMicrophonePreference() {
  try { return localStorage.getItem('tm-local-microphone-device-id') !== null; }
  catch (_) { return false; }
}

function saveMicrophoneId(deviceId) {
  try {
    localStorage.setItem('tm-local-microphone-device-id', deviceId || SYSTEM_DEFAULT_MICROPHONE);
  } catch (_) {}
}

function toast(message, type = '') {
  const node = document.createElement('div');
  node.className = `toast ${type}`.trim();
  node.textContent = message;
  elements.toastRegion.appendChild(node);
  setTimeout(() => node.remove(), 5200);
}

function setBusy(active, text = '處理中…') {
  elements.busyText.textContent = text;
  elements.busyOverlay.classList.toggle('hidden', !active);
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const payload = await response.json();
      detail = payload.detail || JSON.stringify(payload);
    } catch (_) {
      detail = (await response.text()) || detail;
    }
    throw new Error(detail);
  }
  const contentType = response.headers.get('content-type') || '';
  if (contentType.includes('application/json')) return response.json();
  return response;
}

function jsonOptions(method, payload) {
  return {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  };
}

async function checkHealth() {
  try {
    const data = await api('/api/health');
    $('#serverStatus').classList.add('online');
    const runtimeLabel = data.runtime?.backend_label || 'CPU';
    const gpuName = Array.isArray(data.runtime?.gpu_names) ? data.runtime.gpu_names[0] : '';
    $('#serverStatus span').textContent = `Local v${data.version} · ${runtimeLabel}`;
    const pill = $('#runtimePill');
    if (pill) {
      const detail = gpuName ? `${runtimeLabel} · ${gpuName}` : runtimeLabel;
      pill.textContent = `LOCAL · PRIVATE · PYTHON 3.13 · ${detail}`;
      pill.title = data.runtime?.reason || detail;
    }
  } catch (error) {
    $('#serverStatus').classList.remove('online');
    $('#serverStatus span').textContent = '本機服務中斷';
  }
}

function routeProjectId() {
  const match = location.hash.match(/^#\/project\/([0-9a-f-]+)$/i);
  return match ? match[1] : null;
}

function goHome() {
  location.hash = '#/';
}

function goProject(projectId) {
  location.hash = `#/project/${projectId}`;
}

async function handleRoute() {
  stopPreview();
  const projectId = routeProjectId();
  if (!projectId) {
    state.project = null;
    state.activePanel = null;
    elements.projectView.classList.add('hidden');
    elements.homeView.classList.remove('hidden');
    elements.projectHeaderTools.classList.add('hidden');
    $('#exportProjectButton').classList.add('hidden');
    $('#deleteProjectButton').classList.add('hidden');
    await loadProjects();
    return;
  }
  elements.homeView.classList.add('hidden');
  elements.projectView.classList.remove('hidden');
  elements.projectHeaderTools.classList.remove('hidden');
  $('#exportProjectButton').classList.remove('hidden');
  $('#deleteProjectButton').classList.remove('hidden');
  await loadProject(projectId);
}

async function loadProjects() {
  try {
    const payload = await api('/api/projects');
    state.projects = payload.projects || [];
    renderRecentProjects();
  } catch (error) {
    toast(`無法讀取專案：${error.message}`, 'error');
  }
}

function renderRecentProjects() {
  elements.recentProjects.innerHTML = '';
  elements.emptyProjects.classList.toggle('hidden', state.projects.length > 0);
  for (const project of state.projects) {
    const kindMeta = projectKindMeta(project.kind);
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'recent-project-card';
    card.innerHTML = `
      <span class="recent-top">
        <span class="recent-kind-icon ${escapeHtml(project.kind)}" title="${escapeHtml(kindMeta.label)} Project">${kindMeta.icon}</span>
        <small>${project.training?.state === 'trained' ? 'Trained' : 'Untrained'}</small>
      </span>
      <strong>${escapeHtml(project.name)}</strong>
      <span class="recent-stats"><span>${project.total_samples || 0} samples</span><span>${escapeHtml(formatDate(project.updated_at))}</span></span>`;
    card.addEventListener('click', () => goProject(project.id));
    elements.recentProjects.appendChild(card);
  }
}

async function createProject(kind) {
  setBusy(true, `建立 ${projectKindMeta(kind).label} Project…`);
  try {
    const project = await api('/api/projects', jsonOptions('POST', { kind }));
    goProject(project.id);
  } catch (error) {
    toast(`建立專案失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function loadProject(projectId, { quiet = false } = {}) {
  try {
    const project = await api(`/api/projects/${projectId}`);
    state.project = project;
    renderProject();
    if (project.active_job && ['queued', 'running'].includes(project.active_job.state)) {
      if (project.active_job.job_type === 'export') {
        state.activeExportJobId = project.active_job.id;
        state.exportStartedAt = Date.now();
        setBusy(true, '恢復模型匯出進度…');
        pollExportJob(project.active_job.id);
      } else {
        pollJob(project.active_job.id);
      }
    }
  } catch (error) {
    if (!quiet) toast(`無法開啟專案：${error.message}`, 'error');
    goHome();
  }
}

function trainingState() {
  return state.project?.training?.state || 'untrained';
}

function classMinimum(project = state.project) {
  if (isAbnormalSoundProject(project)) {
    const settings = project?.settings || {};
    const clipSeconds = Math.max(0.1, Number(settings.clip_seconds || 1));
    return Math.max(1, Math.ceil(Number(settings.minimum_train_seconds || clipSeconds) / clipSeconds));
  }
  if (isKnownSoundProject(project)) {
    return Number(project?.settings?.minimum_clips_per_class || 20);
  }
  return Number(project?.minimum_samples_per_class || project?.settings?.minimum_samples_per_class || (project?.kind === 'audio' ? 8 : 5));
}

// Known Sound also needs several INDEPENDENT recording sessions per class, because a
// single 20 s take sliced into 20 clips is one example, not twenty, and cannot be split
// into train/validation without leaking.
function knownSoundSessionMinimum(project = state.project) {
  return Number(project?.settings?.minimum_sessions_per_class || 2);
}

function canTrain() {
  if (!state.project) return false;
  if (isAbnormalSoundProject()) return abnormalTrainingReadiness().ready;
  if (state.project.classes.length < 2) return false;
  const minimum = classMinimum();
  if (isKnownSoundProject()) {
    const sessionMinimum = knownSoundSessionMinimum();
    return state.project.classes.every(item => (
      Number(item.sample_count || 0) >= minimum && classSessionCount(item) >= sessionMinimum
    ));
  }
  return state.project.classes.every(item => Number(item.sample_count || 0) >= minimum);
}

function renderProject() {
  const project = state.project;
  if (!project) return;
  const kindMeta = projectKindMeta(project.kind);
  const abnormal = isAbnormalSoundProject(project);
  elements.projectNameInput.value = project.name;
  elements.projectKindBadge.textContent = `${kindMeta.label.toUpperCase()} PROJECT`;
  if (abnormal) {
    const readiness = abnormalTrainingReadiness(project);
    const evaluationSamples = (project.classes || []).reduce((total, item, index) => (
      projectClassRole(item, index, project) === ANOMALY_EVAL_ROLE
        ? total + Number(item.sample_count || 0)
        : total
    ), 0);
    elements.projectSampleSummary.textContent = `${readiness.clips} Normal samples · ${readiness.sessions} sessions · ${evaluationSamples} evaluation samples`;
  } else {
    elements.projectSampleSummary.textContent = `${project.total_samples || 0} samples · ${project.classes.length} classes`;
  }
  $('#addClassButton').innerHTML = abnormal
    ? '<span>⊞</span> Add anomaly evaluation group'
    : '<span>⊞</span> Add a class';
  renderClasses();
  renderTrainingOptions();
  renderTrainingPanel();
  renderPreviewPanel();
  $('#audioExportNotice').classList.toggle('hidden', project.kind !== 'audio');
  $('#abnormalSoundExportNotice').classList.toggle('hidden', !abnormal);
  elements.microphoneDeviceControls.classList.toggle('hidden', !isAudioLikeProject(project));
  setTimeout(() => {
    if (isAudioLikeProject(project)) refreshMicrophoneDevices({ silent: true });
    restoreActivePanelMedia();
    drawConnectors();
  }, 20);
}

function renderClasses() {
  const project = state.project;
  const abnormal = isAbnormalSoundProject(project);
  const readiness = abnormal ? abnormalTrainingReadiness(project) : null;
  elements.classStack.innerHTML = '';
  for (const [index, classItem] of project.classes.entries()) {
    const role = projectClassRole(classItem, index, project);
    const isNormal = role === NORMAL_TRAIN_ROLE;
    const card = document.createElement('article');
    card.className = `class-card${abnormal ? ` abnormal-role-${role}` : ''}`;
    card.dataset.classId = classItem.id;
    if (role) card.dataset.role = role;
    card.style.setProperty('--class-color', classItem.color);
    const minimum = classMinimum(project);
    const samples = classItem.samples || [];
    const sampleHtml = samples.length
      ? samples.map(sample => `
          <span class="sample-thumb" data-sample-id="${escapeHtml(sample.id)}">
            <img src="${escapeHtml(sample.thumbnail_url)}" alt="sample" loading="lazy">
            <button type="button" data-delete-sample="${escapeHtml(sample.id)}" title="刪除">×</button>
          </span>`).join('')
      : '<span class="empty-sample-strip">No samples yet</span>';
    const sourceLabel = project.kind === 'image' ? ['▣', 'Webcam'] : ['♩', 'Mic'];
    const active = state.activePanel?.classId === classItem.id;
    let roleBadge = '';
    let sampleSummary = `
      <strong>${classItem.sample_count || 0} ${project.kind === 'image' ? 'Image' : 'Audio'} Samples <span>/ ${minimum} minimum</span></strong>
      <small>${classItem.sample_count >= minimum ? 'Ready for training' : `Add ${Math.max(0, minimum - classItem.sample_count)} more sample(s)`}</small>`;
    if (abnormal && isNormal) {
      const seconds = Number(classItem.duration_seconds ?? classItem.total_duration_seconds ?? Number(classItem.sample_count || 0) * Number(project.settings?.clip_seconds || 1));
      const sessions = classSessionCount(classItem);
      roleBadge = '<span class="class-role-badge normal">NORMAL BASELINE · TRAINING</span>';
      sampleSummary = `
        <strong>${classItem.sample_count || 0} Normal Audio Samples</strong>
        <small>${seconds.toFixed(0)} s / ${readiness.minimumSeconds.toFixed(0)} s · ${sessions} / ${readiness.minimumSessions} independent sessions</small>`;
    } else if (abnormal) {
      roleBadge = '<span class="class-role-badge evaluation">ANOMALY EVALUATION ONLY</span>';
      sampleSummary = `
        <strong>${classItem.sample_count || 0} Evaluation Audio Samples</strong>
        <small>Never used for training, calibration, or threshold selection</small>`;
    } else if (isKnownSoundProject(project)) {
      // Sessions matter as much as clip count here, and the difference is invisible
      // unless the card says so: 20 clips sliced from one take is ONE example.
      const sessions = classSessionCount(classItem);
      const sessionMinimum = knownSoundSessionMinimum(project);
      const clipsShort = Math.max(0, minimum - Number(classItem.sample_count || 0));
      const sessionsShort = Math.max(0, sessionMinimum - sessions);
      const todo = [];
      if (clipsShort) todo.push(`再 ${clipsShort} 個片段`);
      if (sessionsShort) todo.push(`再 ${sessionsShort} 次獨立錄音`);
      sampleSummary = `
        <strong>${classItem.sample_count || 0} Audio Samples <span>/ ${minimum} minimum</span></strong>
        <small>${sessions} / ${sessionMinimum} 次獨立錄音 · ${todo.length ? `還需要${todo.join('、')}` : 'Ready for training'}</small>`;
    }
    card.innerHTML = `
      <div class="class-card-header">
        <input class="class-name-input" value="${escapeHtml(classItem.name)}" maxlength="80" aria-label="${abnormal ? '資料群組名稱' : '類別名稱'}" ${isNormal ? 'readonly title="Normal baseline role is locked"' : ''}>
        ${roleBadge}
        <button class="class-menu-button" type="button" aria-label="類別選單">⋮</button>
        <div class="class-action-menu hidden">
          <button type="button" data-action="clear">Clear samples</button>
          ${isNormal ? '' : `<button type="button" data-action="delete" class="danger">${abnormal ? 'Delete evaluation group' : 'Delete class'}</button>`}
        </div>
      </div>
      <div class="class-card-body">
        <div class="class-summary-row">
          <div class="sample-count-copy">
            ${sampleSummary}
          </div>
          <div class="source-buttons">
            <button class="source-button ${active ? 'active' : ''}" type="button" data-open-capture="${classItem.id}"><b>${sourceLabel[0]}</b>${sourceLabel[1]}</button>
            <button class="source-button" type="button" data-open-upload="${classItem.id}"><b>↥</b>Upload</button>
          </div>
          <div class="sample-strip">${sampleHtml}</div>
        </div>
        ${active ? renderCapturePanel(classItem) : ''}
      </div>`;
    wireClassCard(card, classItem);
    elements.classStack.appendChild(card);
  }
}

function renderCapturePanel(classItem) {
  if (state.project.kind === 'image') {
    return `
      <div class="class-input-panel">
        <div class="capture-pane">
          <button class="class-panel-close" type="button" data-close-panel>×</button>
          <video id="classCaptureVideo" autoplay playsinline muted></video>
          <button id="holdCaptureButton" class="record-button" type="button">Hold to Record</button>
          <small class="capture-help">按住按鈕連續擷取；放開後會自動加入 ${escapeHtml(classItem.name)}。</small>
        </div>
        <div class="capture-results">
          <h4>Add Image Samples:</h4>
          <p id="captureResultText">把物件放在鏡頭前。建議改變角度、距離與背景。</p>
          <div class="capture-progress"><i id="captureProgressBar"></i></div>
        </div>
      </div>`;
  }
  const index = state.project.classes.findIndex(item => item.id === classItem.id);
  const role = projectClassRole(classItem, Math.max(0, index));
  const abnormal = isAbnormalSoundProject();
  const isNormal = role === NORMAL_TRAIN_ROLE;
  const heading = abnormal
    ? (isNormal ? 'Add Normal Baseline Audio:' : 'Add Evaluation-only Anomaly Audio:')
    : 'Add Audio Samples:';
  const help = abnormal
    ? (isNormal
      ? '每次錄音是一個獨立 session。請跨不同日期、距離與正常運轉條件收集；只錄 Normal。'
      : '此群組只衡量偵測效果，不會加入訓練、校正或 threshold。')
    : '錄音會自動切成 1 秒樣本。Background Noise 建議錄製教室實際環境。';
  const resultHelp = abnormal
    ? (isNormal
      ? '至少收集多個獨立 recording sessions；大量連續 clips 仍只算一個 session。'
      : '使用訓練時未見過的異常錄音，避免用 evaluation 資料調整模型。')
    : '按下錄音，再按一次停止。至少錄製多種音量與距離。';
  return `
    <div class="class-input-panel">
      <div class="capture-pane audio">
        <button class="class-panel-close" type="button" data-close-panel>×</button>
        <div class="audio-meter"><canvas id="classAudioMeter" width="360" height="150"></canvas></div>
        <button id="audioRecordButton" class="record-button" type="button">Record 20 Seconds</button>
        <small id="classMicrophoneSettings" class="capture-device-settings">${escapeHtml(formatMicrophoneSettings())}</small>
        <small class="capture-help">${help}</small>
      </div>
      <div class="capture-results">
        <h4>${heading}</h4>
        <p id="captureResultText">${resultHelp}</p>
        <div class="capture-progress"><i id="captureProgressBar"></i></div>
      </div>
    </div>`;
}

function wireClassCard(card, classItem) {
  const nameInput = card.querySelector('.class-name-input');
  const classIndex = state.project.classes.findIndex(item => item.id === classItem.id);
  const role = projectClassRole(classItem, Math.max(0, classIndex));
  const isNormal = role === NORMAL_TRAIN_ROLE;
  let originalName = classItem.name;
  async function saveClassName() {
    if (nameInput.readOnly) return;
    const value = nameInput.value.trim() || originalName;
    if (value === originalName) return;
    try {
      state.project = await api(`/api/projects/${state.project.id}/classes/${classItem.id}`, jsonOptions('PATCH', { name: value }));
      originalName = value;
      renderProject();
    } catch (error) {
      nameInput.value = originalName;
      toast(`類別重新命名失敗：${error.message}`, 'error');
    }
  }
  if (!nameInput.readOnly) {
    nameInput.addEventListener('change', saveClassName);
    nameInput.addEventListener('keydown', event => { if (event.key === 'Enter') nameInput.blur(); });
  }

  const menu = card.querySelector('.class-action-menu');
  card.querySelector('.class-menu-button').addEventListener('click', event => {
    event.stopPropagation();
    $$('.class-action-menu').forEach(node => { if (node !== menu) node.classList.add('hidden'); });
    menu.classList.toggle('hidden');
  });
  menu.querySelector('[data-action="clear"]').addEventListener('click', async () => {
    menu.classList.add('hidden');
    const warning = isNormal
      ? '這會清除全部 Normal baseline，已訓練模型與 threshold 也會失效。'
      : `確定要清除「${classItem.name}」的全部樣本嗎？`;
    const ok = await confirmDialog('清除所有樣本', warning);
    if (!ok) return;
    await mutateProject(`/api/projects/${state.project.id}/classes/${classItem.id}/samples`, { method: 'DELETE' }, '樣本已清除');
  });
  const deleteButton = menu.querySelector('[data-action="delete"]');
  if (deleteButton) {
    deleteButton.addEventListener('click', async () => {
      menu.classList.add('hidden');
      const noun = isAbnormalSoundProject() ? 'evaluation group' : '類別';
      const ok = await confirmDialog(`刪除 ${noun}`, `將刪除「${classItem.name}」以及其中所有樣本，無法復原。`);
      if (!ok) return;
      await mutateProject(`/api/projects/${state.project.id}/classes/${classItem.id}`, { method: 'DELETE' }, `${noun} 已刪除`);
    });
  }

  card.querySelector('[data-open-capture]').addEventListener('click', () => {
    state.activePanel = state.activePanel?.classId === classItem.id ? null : { classId: classItem.id };
    renderProject();
  });
  card.querySelector('[data-open-upload]').addEventListener('click', () => openSampleUpload(classItem));
  card.querySelectorAll('[data-delete-sample]').forEach(button => {
    button.addEventListener('click', async event => {
      event.stopPropagation();
      const sampleId = button.dataset.deleteSample;
      try {
        state.project = await api(`/api/projects/${state.project.id}/samples/${sampleId}`, { method: 'DELETE' });
        renderProject();
      } catch (error) {
        toast(`刪除樣本失敗：${error.message}`, 'error');
      }
    });
  });
  const close = card.querySelector('[data-close-panel]');
  if (close) close.addEventListener('click', () => { state.activePanel = null; renderProject(); });
}

async function mutateProject(path, options, successMessage = '') {
  setBusy(true);
  try {
    state.project = await api(path, options);
    renderProject();
    if (successMessage) toast(successMessage, 'success');
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    setBusy(false);
  }
}

function restoreActivePanelMedia() {
  if (!state.activePanel || !state.project) return;
  if (state.project.kind === 'image') setupImageCapturePanel();
  else setupAudioCapturePanel();
}

async function openSampleUpload(classItem) {
  const input = document.createElement('input');
  input.type = 'file';
  input.multiple = true;
  input.accept = state.project.kind === 'image' ? 'image/*' : 'audio/*,.wav,.mp3,.m4a,.ogg,.flac';
  input.addEventListener('change', async () => {
    if (!input.files?.length) return;
    if (state.project.kind === 'image') await uploadImageFiles(classItem.id, [...input.files]);
    else await uploadAudioFiles(classItem.id, [...input.files]);
  });
  input.click();
}

async function uploadImageFiles(classId, files) {
  setBusy(true, `加入 ${files.length} 張圖片…`);
  try {
    for (let start = 0; start < files.length; start += 40) {
      const data = new FormData();
      for (const file of files.slice(start, start + 40)) data.append('files', file, file.name);
      const result = await api(`/api/projects/${state.project.id}/classes/${classId}/images`, { method: 'POST', body: data });
      state.project = result.project;
      if (result.errors?.length) toast(result.errors.slice(0, 3).join('\n'), 'error');
    }
    renderProject();
    toast('圖片樣本已加入', 'success');
  } catch (error) {
    toast(`圖片上傳失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function uploadAudioFiles(classId, files) {
  setBusy(true, `解碼 ${files.length} 個音訊檔…`);
  try {
    const wavEntries = [];
    for (let index = 0; index < files.length; index += 1) {
      elements.busyText.textContent = `解碼音訊 ${index + 1}/${files.length}…`;
      const arrayBuffer = await files[index].arrayBuffer();
      const context = new (window.AudioContext || window.webkitAudioContext)();
      let decoded;
      try {
        decoded = await context.decodeAudioData(arrayBuffer.slice(0));
      } finally {
        await context.close();
      }
      const mono = mixAudioBufferToMono(decoded);
      const wavBlob = encodeWavBlob(mono, decoded.sampleRate);
      wavEntries.push({
        file: new File([wavBlob], `${files[index].name.replace(/\.[^.]+$/, '')}.wav`, { type: 'audio/wav' }),
        originalName: files[index].name,
        decodedSampleRate: decoded.sampleRate,
      });
    }
    let added = 0;
    const errors = [];
    if (isAbnormalSoundProject()) {
      // Each source file is one independent recording session. Sending one per request keeps
      // the session boundary unambiguous even when the server cuts it into many 1 s clips.
      for (let index = 0; index < wavEntries.length; index += 1) {
        elements.busyText.textContent = `加入音訊 session ${index + 1}/${wavEntries.length}…`;
        const entry = wavEntries[index];
        const metadata = {
          recording_session_id: newRecordingSessionId(),
          source: 'upload',
          source_name: entry.originalName,
          device_label: 'Uploaded audio file',
          device_id: '',
          device_settings: { decoded_sample_rate: entry.decodedSampleRate },
        };
        const result = await postAudioWavFiles(classId, [entry.file], metadata);
        added += Number(result.added || 0);
        errors.push(...(result.errors || []));
      }
    } else {
      const wavFiles = wavEntries.map(entry => entry.file);
      for (let start = 0; start < wavFiles.length; start += 20) {
        const result = await postAudioWavFiles(classId, wavFiles.slice(start, start + 20));
        added += Number(result.added || 0);
        errors.push(...(result.errors || []));
      }
    }
    renderProject();
    if (errors.length) toast(errors.slice(0, 3).join('\n'), 'error');
    else toast(`已加入 ${added} 個音訊樣本`, 'success');
  } catch (error) {
    toast(`音訊上傳失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

function currentAudioSessionMetadata(sessionId, source = 'microphone') {
  const track = state.audioStream?.getAudioTracks?.()[0];
  const settings = track?.getSettings?.() || state.audioTrackSettings || {};
  return {
    recording_session_id: sessionId || newRecordingSessionId(),
    source,
    device_label: track?.label || selectedMicrophoneLabel() || 'System default microphone',
    device_id: String(settings.deviceId || state.audioDeviceId || ''),
    device_settings: settings,
  };
}

function appendAudioSessionMetadata(data, metadata) {
  if (!metadata) return;
  data.append('recording_session_id', String(metadata.recording_session_id || ''));
  data.append('device_label', String(metadata.device_label || ''));
  data.append('device_id', String(metadata.device_id || ''));
  data.append('device_settings', JSON.stringify(metadata.device_settings || {}));
  data.append('device_metadata', JSON.stringify({
    label: metadata.device_label || '',
    device_id: metadata.device_id || '',
    source: metadata.source || '',
    settings: metadata.device_settings || {},
  }));
  data.append('session_metadata', JSON.stringify(metadata));
}

async function postAudioWavFiles(classId, wavFiles, metadata = null) {
  const data = new FormData();
  wavFiles.forEach(file => data.append('files', file, file.name));
  data.append('overlap', '0');
  appendAudioSessionMetadata(data, metadata);
  const result = await api(`/api/projects/${state.project.id}/classes/${classId}/audio`, { method: 'POST', body: data });
  state.project = result.project;
  return result;
}

async function ensureCamera() {
  if (state.cameraStream?.active) return state.cameraStream;
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('瀏覽器不支援 Webcam。');
  state.cameraStream = await navigator.mediaDevices.getUserMedia({
    video: { width: { ideal: 640 }, height: { ideal: 640 }, facingMode: 'user' },
    audio: false,
  });
  $('#stopMediaButton').classList.remove('hidden');
  return state.cameraStream;
}

async function setupImageCapturePanel() {
  const video = $('#classCaptureVideo');
  if (!video) return;
  try {
    video.srcObject = await ensureCamera();
    await video.play().catch(() => {});
  } catch (error) {
    toast(`無法啟動相機：${error.message}`, 'error');
    return;
  }
  const button = $('#holdCaptureButton');
  if (!button) return;
  const start = event => {
    event.preventDefault();
    if (state.imageCaptureTimer) return;
    state.imageCaptureBlobs = [];
    state.imageCaptureClassId = state.activePanel?.classId || null;
    state.imageCaptureStartedAt = performance.now();
    button.textContent = 'Recording… release to stop';
    button.classList.add('recording');
    captureImageFrame(video);
    state.imageCaptureTimer = setInterval(() => captureImageFrame(video), 260);
  };
  const stop = event => {
    if (event) event.preventDefault();
    stopImageCapture(button);
  };
  button.addEventListener('pointerdown', start);
  button.addEventListener('pointerup', stop);
  button.addEventListener('pointercancel', stop);
  button.addEventListener('pointerleave', event => { if (event.buttons === 1) stop(event); });
  window.addEventListener('pointerup', stop, { once: true });
}

function captureImageFrame(video) {
  if (!video.videoWidth || !video.videoHeight) return;
  const canvas = document.createElement('canvas');
  const side = Math.min(video.videoWidth, video.videoHeight);
  canvas.width = 320;
  canvas.height = 320;
  const x = (video.videoWidth - side) / 2;
  const y = (video.videoHeight - side) / 2;
  canvas.getContext('2d').drawImage(video, x, y, side, side, 0, 0, 320, 320);
  canvas.toBlob(blob => {
    if (blob) state.imageCaptureBlobs.push(blob);
    const text = $('#captureResultText');
    const bar = $('#captureProgressBar');
    if (text) text.textContent = `${state.imageCaptureBlobs.length} images captured…`;
    if (bar) bar.style.width = `${Math.min(100, state.imageCaptureBlobs.length * 4)}%`;
  }, 'image/jpeg', 0.90);
}

async function stopImageCapture(button) {
  if (!state.imageCaptureTimer) return;
  clearInterval(state.imageCaptureTimer);
  state.imageCaptureTimer = null;
  button?.classList.remove('recording');
  if (button) button.textContent = 'Hold to Record';
  const blobs = state.imageCaptureBlobs.splice(0);
  const classId = state.imageCaptureClassId;
  state.imageCaptureClassId = null;
  if (!blobs.length || !classId) return;
  const files = blobs.map((blob, index) => new File([blob], `webcam_${Date.now()}_${index}.jpg`, { type: 'image/jpeg' }));
  await uploadImageFiles(classId, files);
}

function microphoneLooksLikeGestureAI(device) {
  return /gesture\s*ai|dmic|0416/i.test(String(device?.label || ''));
}

function selectedMicrophoneLabel() {
  const option = elements.microphoneDeviceSelect?.selectedOptions?.[0];
  return option?.dataset?.deviceLabel || option?.textContent || '';
}

function formatMicrophoneSettings() {
  const track = state.audioStream?.getAudioTracks?.()[0];
  const settings = track?.getSettings?.() || state.audioTrackSettings || {};
  if (!track && !Object.keys(settings).length) {
    const selected = selectedMicrophoneLabel();
    return selected ? `${selected} · 尚未開始收音` : '尚未開始收音；按 Mic 或 Preview 後顯示實際設定';
  }
  const parts = [track?.label || selectedMicrophoneLabel() || 'Microphone'];
  if (settings.sampleRate) parts.push(`${settings.sampleRate} Hz`);
  if (settings.channelCount) parts.push(`${settings.channelCount} ch`);
  for (const [key, label] of [
    ['echoCancellation', 'EC'],
    ['noiseSuppression', 'NS'],
    ['autoGainControl', 'AGC'],
  ]) {
    if (typeof settings[key] === 'boolean') parts.push(`${label} ${settings[key] ? 'on' : 'off'}`);
  }
  return parts.join(' · ');
}

function updateMicrophoneSettingsDisplay() {
  const text = formatMicrophoneSettings();
  if (elements.microphoneTrackSettings) {
    elements.microphoneTrackSettings.textContent = text;
    elements.microphoneTrackSettings.title = text;
  }
  const captureSettings = $('#classMicrophoneSettings');
  if (captureSettings) {
    captureSettings.textContent = text;
    captureSettings.title = text;
  }
}

async function refreshMicrophoneDevices({ silent = false } = {}) {
  if (state.microphoneRefreshBusy || !navigator.mediaDevices?.enumerateDevices) return;
  state.microphoneRefreshBusy = true;
  try {
    const devices = (await navigator.mediaDevices.enumerateDevices()).filter(device => device.kind === 'audioinput');
    state.audioDevices = devices;
    const saved = readSavedMicrophoneId();
    const hasPreference = hasSavedMicrophonePreference();
    const current = state.audioDeviceId || saved;
    const currentExists = devices.some(device => device.deviceId === current);
    const gestureAI = devices.find(microphoneLooksLikeGestureAI);
    const nextId = hasPreference
      ? (current && currentExists ? current : '')
      : (currentExists ? current : (gestureAI?.deviceId || ''));
    state.audioDeviceId = nextId;
    const options = ['<option value="">系統預設麥克風</option>'];
    devices.forEach((device, index) => {
      const label = device.label || `Microphone ${index + 1}（允許權限後顯示名稱）`;
      const gestureLabel = microphoneLooksLikeGestureAI(device) ? ' · GestureAI candidate' : '';
      options.push(`<option value="${escapeHtml(device.deviceId)}" data-device-label="${escapeHtml(label)}">${escapeHtml(label + gestureLabel)}</option>`);
    });
    elements.microphoneDeviceSelect.innerHTML = options.join('');
    elements.microphoneDeviceSelect.value = nextId;
    if (nextId) saveMicrophoneId(nextId);
    updateMicrophoneSettingsDisplay();
  } catch (error) {
    if (!silent) toast(`無法列出麥克風：${error.message}`, 'error');
  } finally {
    state.microphoneRefreshBusy = false;
  }
}

async function openSelectedAudioStream() {
  const requestedId = state.audioDeviceId || elements.microphoneDeviceSelect?.value || readSavedMicrophoneId();
  const audio = {
    channelCount: 1,
    echoCancellation: false,
    noiseSuppression: false,
    autoGainControl: false,
  };
  if (requestedId) audio.deviceId = { exact: requestedId };
  try {
    return await navigator.mediaDevices.getUserMedia({ audio, video: false });
  } catch (error) {
    if (!requestedId) throw error;
    state.audioDeviceId = '';
    saveMicrophoneId('');
    if (elements.microphoneDeviceSelect) elements.microphoneDeviceSelect.value = '';
    toast('先前選取的麥克風無法使用，已改用系統預設麥克風。', 'error');
    const fallback = { ...audio };
    delete fallback.deviceId;
    return navigator.mediaDevices.getUserMedia({ audio: fallback, video: false });
  }
}

async function ensureAudio() {
  if (state.audioContext && state.audioContext.state !== 'closed') {
    if (state.audioContext.state === 'suspended') await state.audioContext.resume();
    return state.audioContext;
  }
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('瀏覽器不支援麥克風。');
  await refreshMicrophoneDevices({ silent: true });
  state.audioStream = await openSelectedAudioStream();

  // Device labels are often hidden until the first permission grant. Refresh once permission
  // exists, then automatically prefer GestureAI/DMIC/0416 only when no device was selected.
  const originallyRequested = hasSavedMicrophonePreference() || Boolean(state.audioDeviceId || readSavedMicrophoneId());
  const activeSettings = state.audioStream.getAudioTracks()[0]?.getSettings?.() || {};
  if (!originallyRequested) {
    await refreshMicrophoneDevices({ silent: true });
    if (state.audioDeviceId && activeSettings.deviceId && state.audioDeviceId !== activeSettings.deviceId) {
      state.audioStream.getTracks().forEach(track => track.stop());
      state.audioStream = await openSelectedAudioStream();
    }
  }
  const activeTrack = state.audioStream.getAudioTracks()[0];
  state.audioTrackSettings = activeTrack?.getSettings?.() || {};
  const Context = window.AudioContext || window.webkitAudioContext;
  state.audioContext = new Context();
  state.audioSource = state.audioContext.createMediaStreamSource(state.audioStream);
  state.audioAnalyser = state.audioContext.createAnalyser();
  state.audioAnalyser.fftSize = 512;
  state.audioAnalyser.smoothingTimeConstant = 0.55;
  state.audioProcessor = state.audioContext.createScriptProcessor(4096, 1, 1);
  state.audioSilentGain = state.audioContext.createGain();
  state.audioSilentGain.gain.value = 0;
  state.audioSource.connect(state.audioAnalyser);
  state.audioSource.connect(state.audioProcessor);
  state.audioProcessor.connect(state.audioSilentGain);
  state.audioSilentGain.connect(state.audioContext.destination);
  state.audioProcessor.onaudioprocess = event => {
    const data = new Float32Array(event.inputBuffer.getChannelData(0));
    appendRollingAudio(data);
    if (state.audioRecording) state.audioRecordedChunks.push(data);
  };
  $('#stopMediaButton').classList.remove('hidden');
  await refreshMicrophoneDevices({ silent: true });
  updateMicrophoneSettingsDisplay();
  startAudioVisualization();
  return state.audioContext;
}

async function releaseAudioInput() {
  if (state.audioProcessor) state.audioProcessor.onaudioprocess = null;
  state.audioStream?.getTracks().forEach(track => track.stop());
  try { await state.audioContext?.close(); } catch (_) {}
  if (state.audioAnimation) cancelAnimationFrame(state.audioAnimation);
  state.audioStream = null;
  state.audioContext = null;
  state.audioSource = null;
  state.audioProcessor = null;
  state.audioAnalyser = null;
  state.audioSilentGain = null;
  state.audioTrackSettings = null;
  state.audioRollingChunks = [];
  state.audioRollingSamples = 0;
  state.audioAnimation = null;
  updateMicrophoneSettingsDisplay();
}

async function selectMicrophoneDevice() {
  const nextId = elements.microphoneDeviceSelect.value;
  const hadActiveAudio = Boolean(state.audioStream || state.audioContext);
  if (state.audioRecording) {
    toast('請先停止並儲存目前錄音，再切換麥克風。', 'error');
    elements.microphoneDeviceSelect.value = state.audioDeviceId || '';
    return;
  }
  state.audioDeviceId = nextId;
  saveMicrophoneId(nextId);
  if (!hadActiveAudio) {
    updateMicrophoneSettingsDisplay();
    return;
  }
  setBusy(true, '切換麥克風…');
  try {
    await releaseAudioInput();
    await ensureAudio();
    toast(`已切換至 ${selectedMicrophoneLabel() || '系統預設麥克風'}`, 'success');
  } catch (error) {
    toast(`無法切換麥克風：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

function appendRollingAudio(chunk) {
  state.audioRollingChunks.push(chunk);
  state.audioRollingSamples += chunk.length;
  const maxSamples = Math.ceil((state.audioContext?.sampleRate || 48000) * 4);
  while (state.audioRollingSamples > maxSamples && state.audioRollingChunks.length > 1) {
    const removed = state.audioRollingChunks.shift();
    state.audioRollingSamples -= removed.length;
  }
}

function recentAudio(seconds = 1) {
  const sampleRate = state.audioContext?.sampleRate || 48000;
  const needed = Math.round(sampleRate * seconds);
  const output = new Float32Array(needed);
  let write = needed;
  for (let index = state.audioRollingChunks.length - 1; index >= 0 && write > 0; index -= 1) {
    const chunk = state.audioRollingChunks[index];
    const count = Math.min(write, chunk.length);
    write -= count;
    output.set(chunk.subarray(chunk.length - count), write);
  }
  return output;
}

async function setupAudioCapturePanel() {
  try {
    await ensureAudio();
  } catch (error) {
    toast(`無法啟動麥克風：${error.message}`, 'error');
    return;
  }
  const button = $('#audioRecordButton');
  if (!button) return;
  button.addEventListener('click', () => {
    if (state.audioRecording) stopAudioRecording();
    else startAudioRecording();
  });
}

function startAudioRecording() {
  state.audioRecordedChunks = [];
  state.audioRecording = true;
  state.audioRecordingClassId = state.activePanel?.classId || null;
  state.audioRecordingSessionId = newRecordingSessionId();
  state.audioRecordStartedAt = performance.now();
  const button = $('#audioRecordButton');
  button?.classList.add('recording');
  if (button) button.textContent = 'Stop Recording';
  const text = $('#captureResultText');
  const bar = $('#captureProgressBar');
  state.audioRecordTimer = setInterval(() => {
    const seconds = (performance.now() - state.audioRecordStartedAt) / 1000;
    if (text) text.textContent = `Recording ${seconds.toFixed(1)} / 20.0 seconds…`;
    if (bar) bar.style.width = `${Math.min(100, seconds / 20 * 100)}%`;
    if (seconds >= 20) stopAudioRecording();
  }, 100);
}

async function stopAudioRecording() {
  if (!state.audioRecording) return;
  state.audioRecording = false;
  if (state.audioRecordTimer) clearInterval(state.audioRecordTimer);
  state.audioRecordTimer = null;
  const button = $('#audioRecordButton');
  button?.classList.remove('recording');
  if (button) button.textContent = 'Record 20 Seconds';
  const chunks = state.audioRecordedChunks.splice(0);
  const classId = state.audioRecordingClassId;
  const sessionId = state.audioRecordingSessionId;
  state.audioRecordingClassId = null;
  state.audioRecordingSessionId = null;
  const length = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
  if (!length || !classId) return;
  const signal = new Float32Array(length);
  let offset = 0;
  for (const chunk of chunks) { signal.set(chunk, offset); offset += chunk.length; }
  const blob = encodeWavBlob(signal, state.audioContext.sampleRate);
  const file = new File([blob], `microphone_${Date.now()}.wav`, { type: 'audio/wav' });
  await uploadAudioWavFiles(classId, [file], currentAudioSessionMetadata(sessionId));
}

async function uploadAudioWavFiles(classId, wavFiles, metadata = null) {
  setBusy(true, '切割並加入音訊樣本…');
  try {
    const result = await postAudioWavFiles(classId, wavFiles, metadata);
    renderProject();
    if (result.errors?.length) toast(result.errors.join('\n'), 'error');
    else toast(`已加入 ${result.added} 個音訊樣本`, 'success');
    await runAudioSanityCheck(wavFiles?.[0]);
  } catch (error) {
    toast(`錄音加入失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

// Ask the official YAMNet tagger what it hears in the clip that was just added. This is
// purely informational -- it never touches training, thresholds or stored metadata -- but
// it is the only thing in the product that can tell a user "you recorded speech, not a
// gunshot" BEFORE they spend an afternoon collecting the wrong audio.
async function runAudioSanityCheck(wavFile) {
  if (!wavFile || !state.project || !isAudioLikeProject()) return;
  try {
    const data = new FormData();
    data.append('file', wavFile, wavFile.name || 'check.wav');
    const result = await api(`/api/projects/${state.project.id}/audio-sanity`, { method: 'POST', body: data });
    if (!result?.available || !result.top?.length) return;
    const summary = result.top
      .map(item => `${item.name} ${formatPercent(Number(item.score) || 0)}`)
      .join(' · ');
    toast(`錄音健檢：這段聽起來像 ${summary}`, 'info');
  } catch (error) {
    // A failed sanity check must never block or undo a successful recording.
    console.warn('audio sanity check failed', error);
  }
}

function startAudioVisualization() {
  if (state.audioAnimation) cancelAnimationFrame(state.audioAnimation);
  const draw = () => {
    drawWaveform($('#classAudioMeter'));
    drawLiveSpectrogram();
    state.audioAnimation = requestAnimationFrame(draw);
  };
  draw();
}

function drawWaveform(canvas) {
  if (!canvas || !state.audioAnalyser) return;
  const context = canvas.getContext('2d');
  const data = new Uint8Array(state.audioAnalyser.fftSize);
  state.audioAnalyser.getByteTimeDomainData(data);
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = '#d7e8ff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = '#1967d2';
  context.lineWidth = 3;
  context.beginPath();
  for (let index = 0; index < data.length; index += 1) {
    const x = index / (data.length - 1) * canvas.width;
    const y = data[index] / 255 * canvas.height;
    if (index === 0) context.moveTo(x, y); else context.lineTo(x, y);
  }
  context.stroke();
}

function drawLiveSpectrogram() {
  const canvas = elements.liveSpectrogramCanvas;
  if (!canvas || canvas.closest('.hidden') || !state.audioAnalyser) return;
  const context = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const previous = context.getImageData(1, 0, width - 1, height);
  context.putImageData(previous, 0, 0);
  const bins = new Uint8Array(state.audioAnalyser.frequencyBinCount);
  state.audioAnalyser.getByteFrequencyData(bins);
  for (let y = 0; y < height; y += 1) {
    const index = Math.floor((1 - y / height) * (bins.length - 1));
    const value = bins[index] / 255;
    const [r, g, b] = spectrogramColor(value);
    context.fillStyle = `rgb(${r},${g},${b})`;
    context.fillRect(width - 1, y, 1, 1);
  }
}

function spectrogramColor(value) {
  const stops = [
    [4, 16, 38], [10, 46, 91], [52, 45, 134], [117, 64, 145], [224, 97, 70], [255, 190, 80],
  ];
  const scaled = Math.max(0, Math.min(1, value)) * (stops.length - 1);
  const low = Math.floor(scaled);
  const high = Math.min(stops.length - 1, low + 1);
  const fraction = scaled - low;
  return stops[low].map((entry, index) => Math.round(entry * (1 - fraction) + stops[high][index] * fraction));
}

function mixAudioBufferToMono(buffer) {
  const output = new Float32Array(buffer.length);
  for (let channel = 0; channel < buffer.numberOfChannels; channel += 1) {
    const input = buffer.getChannelData(channel);
    for (let index = 0; index < input.length; index += 1) output[index] += input[index] / buffer.numberOfChannels;
  }
  return output;
}

function encodeWavBlob(signal, sampleRate) {
  const buffer = new ArrayBuffer(44 + signal.length * 2);
  const view = new DataView(buffer);
  const writeString = (offset, value) => { for (let i = 0; i < value.length; i += 1) view.setUint8(offset + i, value.charCodeAt(i)); };
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + signal.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, signal.length * 2, true);
  for (let index = 0; index < signal.length; index += 1) {
    const sample = Math.max(-1, Math.min(1, signal[index]));
    view.setInt16(44 + index * 2, sample < 0 ? sample * 32768 : sample * 32767, true);
  }
  return new Blob([buffer], { type: 'audio/wav' });
}

function renderTrainingOptions() {
  const settings = state.project.settings || {};
  const common = `
    <label>Epochs<input id="optEpochs" type="number" min="1" max="300" value="${Number(settings.epochs || 30)}"></label>
    <label>Batch Size<input id="optBatchSize" type="number" min="1" max="128" value="${Number(settings.batch_size || 16)}"></label>
    <label>Learning Rate<input id="optLearningRate" type="number" min="0.000001" max="0.1" step="0.0001" value="${Number(settings.learning_rate || 0.001)}"></label>
    <label>Validation Split<input id="optValidationSplit" type="number" min="0" max="0.45" step="0.05" value="${Number(settings.validation_split || 0.2)}"></label>
    <label class="inline-check"><input id="optEarlyStopping" type="checkbox" ${settings.early_stopping !== false ? 'checked' : ''}> Early stopping</label>`;
  if (state.project.kind === 'image') {
    elements.trainingOptions.innerHTML = `
      <label>Model<select id="optBackbone"><option value="mobilenet_v2" ${settings.backbone !== 'small_cnn' ? 'selected' : ''}>MobileNetV2 transfer learning</option><option value="small_cnn" ${settings.backbone === 'small_cnn' ? 'selected' : ''}>Small CNN (offline)</option></select></label>
      <label>MobileNet Size<select id="optMobileNetAlpha"><option value="0.35" ${Number(settings.mobilenet_alpha || 0.35) === 0.35 ? 'selected' : ''}>0.35 · Teachable Machine default / fast</option><option value="0.5" ${Number(settings.mobilenet_alpha) === 0.5 ? 'selected' : ''}>0.50</option><option value="0.75" ${Number(settings.mobilenet_alpha) === 0.75 ? 'selected' : ''}>0.75 · SRAM已放不下 或降resolution</option><option value="1" ${Number(settings.mobilenet_alpha) === 1 ? 'selected' : ''}>1.00 · SRAM已放不下 或降resolution</option></select></label>
      <label>Image Size<select id="optImageSize"><option value="224" ${Number(settings.image_size) === 224 ? 'selected' : ''}>224 × 224</option><option value="160" ${Number(settings.image_size) === 160 ? 'selected' : ''}>160 × 160</option><option value="128" ${Number(settings.image_size) === 128 ? 'selected' : ''}>128 × 128</option></select></label>${common}`;
  } else if (state.project.kind === 'audio') {
    elements.trainingOptions.innerHTML = `
      <label>Sample Rate<select id="optSampleRate"><option value="16000" ${Number(settings.sample_rate) === 16000 ? 'selected' : ''}>16 kHz</option><option value="44100" ${Number(settings.sample_rate) === 44100 ? 'selected' : ''}>44.1 kHz</option></select></label>
      <label>Mel Bins<select id="optMelBins"><option value="40" ${Number(settings.mel_bins) === 40 ? 'selected' : ''}>40</option><option value="64" ${Number(settings.mel_bins) === 64 ? 'selected' : ''}>64</option></select></label>${common}`;
  } else if (state.project.kind === 'known_sound') {
    const threshold = Number(settings.detection_threshold || 0.5);
    const mixup = Number(settings.mixup_ratio ?? 0.5);
    const depth = Number(settings.encoder_depth ?? 14);
    // Post-Vela flash on NuMaker-GestureAI-M55M1 (ethos-u55-256 / Shared_Sram), measured.
    // Tensor-arena SRAM is ~151 KB at every depth, so this trades flash only.
    const depthChoices = [
      [14, '完整 14 層 · 約 2.97 MB · PC／高階裝置'],
      [12, '12 層 · 約 1.56 MB'],
      [11, '11 層 · 約 1.31 MB'],
      [10, '10 層 · 約 1.05 MB · 建議給 2 MB flash MCU'],
      [9, '9 層 · 約 0.78 MB'],
      [8, '8 層 · 約 0.53 MB'],
      [7, '7 層 · 約 0.27 MB'],
      [6, '6 層 · 約 0.14 MB · 最小'],
    ];
    elements.trainingOptions.innerHTML = `
      <div class="yamnet-training-note">
        <strong>YAMNet · Frozen embedding + 分類頭</strong>
        <small>16 kHz mono → frozen embedding → 每類一個獨立 sigmoid。只訓練最後一層小分類頭，預訓練權重不會被微調。驗證一律以「整段錄音」為單位切分，同一段錄音不會同時出現在訓練與驗證。</small>
      </div>
      <label>Model<input type="text" value="YAMNet embedding (frozen) + sigmoid head" readonly></label>
      <label>Frontend<input type="text" value="16 kHz · 64 mel · 0.96 s patch" readonly></label>
      <label>Encoder 深度<select id="optEncoderDepth">
        ${depthChoices.map(([value, label]) => (
          `<option value="${value}" ${depth === value ? 'selected' : ''}>${escapeHtml(label)}</option>`
        )).join('')}
      </select></label>
      <label>偵測門檻<input id="optDetectionThreshold" type="number" min="0.05" max="0.95" step="0.05" value="${threshold}"></label>
      <label>混音增強<select id="optMixupRatio">
        <option value="0" ${mixup === 0 ? 'selected' : ''}>關閉</option>
        <option value="0.5" ${mixup === 0.5 ? 'selected' : ''}>0.5 × （建議）</option>
        <option value="1" ${mixup === 1 ? 'selected' : ''}>1.0 ×</option>
      </select></label>
      <label>Epochs<input id="optEpochs" type="number" min="1" max="500" value="${Number(settings.epochs || 120)}"></label>
      <label>Batch Size<input id="optBatchSize" type="number" min="1" max="128" value="${Number(settings.batch_size || 32)}"></label>
      <label>Learning Rate<input id="optLearningRate" type="number" min="0.000001" max="0.1" step="0.0001" value="${Number(settings.learning_rate || 0.001)}"></label>
      <label class="inline-check"><input id="optEarlyStopping" type="checkbox" ${settings.early_stopping !== false ? 'checked' : ''}> Early stopping</label>`;
  } else {
    const sensitivity = String(settings.sensitivity || 'balanced');
    elements.trainingOptions.innerHTML = `
      <div class="yamnet-training-note">
        <strong>YAMNet · Frozen embedding</strong>
        <small>16 kHz mono → frozen 1024-D embedding → Normal-only scorer. Encoder weights are not fine-tuned, and anomaly evaluation groups never enter training or threshold calibration.</small>
      </div>
      <label>Model<input type="text" value="YAMNet embedding (frozen)" readonly></label>
      <label>Frontend<input type="text" value="16 kHz · 64 mel · 0.96 s patch" readonly></label>
      <label>Sensitivity<select id="optSensitivity">
        <option value="sensitive" ${sensitivity === 'sensitive' ? 'selected' : ''}>Sensitive · more detections</option>
        <option value="balanced" ${sensitivity === 'balanced' ? 'selected' : ''}>Balanced</option>
        <option value="low_false_alarm" ${sensitivity === 'low_false_alarm' ? 'selected' : ''}>Low false alarm</option>
      </select></label>`;
  }
}

function readTrainingOptions() {
  if (isAbnormalSoundProject()) {
    return {
      detector_backend: 'yamnet_embedding',
      sample_rate: 16000,
      sensitivity: $('#optSensitivity').value,
    };
  }
  if (isKnownSoundProject()) {
    // No validation_split: the split is by recording session, not by a clip fraction.
    return {
      encoder_backend: 'yamnet_embedding',
      sample_rate: 16000,
      epochs: Number($('#optEpochs').value),
      batch_size: Number($('#optBatchSize').value),
      learning_rate: Number($('#optLearningRate').value),
      early_stopping: $('#optEarlyStopping').checked,
      detection_threshold: Number($('#optDetectionThreshold').value),
      mixup_ratio: Number($('#optMixupRatio').value),
      encoder_depth: Number($('#optEncoderDepth').value),
    };
  }
  const options = {
    epochs: Number($('#optEpochs').value),
    batch_size: Number($('#optBatchSize').value),
    learning_rate: Number($('#optLearningRate').value),
    validation_split: Number($('#optValidationSplit').value),
    early_stopping: $('#optEarlyStopping').checked,
  };
  if (state.project.kind === 'image') {
    options.backbone = $('#optBackbone').value;
    options.mobilenet_alpha = Number($('#optMobileNetAlpha').value);
    options.image_size = Number($('#optImageSize').value);
  } else {
    options.sample_rate = Number($('#optSampleRate').value);
    options.mel_bins = Number($('#optMelBins').value);
    options.fft_size = options.sample_rate >= 32000 ? 2048 : 512;
    options.fmax = options.sample_rate / 2;
  }
  return options;
}

function renderTrainingPanel() {
  const status = trainingState();
  const isTraining = status === 'training' || Boolean(state.activeJobId);
  elements.trainingIdle.classList.toggle('hidden', status === 'trained' || isTraining);
  elements.trainingProgress.classList.toggle('hidden', !isTraining);
  elements.trainingDone.classList.toggle('hidden', status !== 'trained' || isTraining);
  elements.trainButton.disabled = !canTrain();
  const minimum = classMinimum();
  if (isAbnormalSoundProject()) {
    const readiness = abnormalTrainingReadiness();
    if (readiness.ready) {
      elements.trainingHint.textContent = readiness.calibrationCandidate
        ? `Normal baseline 已有 ${readiness.seconds.toFixed(0)} 秒、${readiness.sessions} 個獨立 sessions。可建立 YAMNet scorer；最終 confidence 仍由 held-out audit 決定。`
        : `已達低信心訓練門檻；可先看 anomaly ratio，但正式 Normal／Abnormal verdict 建議至少 ${readiness.calibrationSeconds.toFixed(0)} 秒、${readiness.calibrationSessions} 個 sessions，且須通過 held-out audit。`;
    } else if (!readiness.clips) {
      elements.trainingHint.textContent = readiness.note || '先在 Normal baseline 收集正常聲音；anomaly evaluation 不會拿來訓練。';
    } else {
      const measured = `Normal baseline 目前 ${readiness.seconds.toFixed(0)} / ${readiness.minimumSeconds.toFixed(0)} 秒、${readiness.sessions} / ${readiness.minimumSessions} 個獨立 sessions。`;
      elements.trainingHint.textContent = `${readiness.note ? `${readiness.note} ` : ''}${measured} 請跨時段重新錄音，不要只延長同一次錄音。`;
    }
  } else {
    elements.trainingHint.textContent = canTrain()
      ? '資料已準備完成。按下 Train Model 開始。'
      : `每個類別至少需要 ${minimum} 個樣本。`;
  }
  if (status === 'trained') {
    const report = state.project.training?.report || {};
    const evaluation = report.evaluation || {};
    const accuracy = evaluation.accuracy;
    const runtime = report.training_runtime || {};
    const runtimeLabel = runtime.label || 'Windows CPU';
    let accuracyText = accuracy == null ? '模型已可預覽與匯出' : `Evaluation accuracy: ${formatPercent(accuracy)}`;
    if (isAbnormalSoundProject()) {
      const confidence = report.readiness?.confidence || report.calibration?.confidence || 'unknown confidence';
      const reason = Array.isArray(report.readiness?.reasons) ? report.readiness.reasons[0] : '';
      accuracyText = `YAMNet anomaly detector ready · calibration ${confidence}${reason ? ` · ${reason}` : ''}`;
    }
    elements.trainingAccuracy.textContent = `${accuracyText} · ${runtimeLabel}`;
  }
}

async function startTraining() {
  if (!canTrain()) {
    if (isAbnormalSoundProject()) {
      const readiness = abnormalTrainingReadiness();
      toast(`Normal baseline 需要至少 ${readiness.minimumSeconds.toFixed(0)} 秒、${readiness.minimumSessions} 個獨立 recording sessions；evaluation groups 不列入要求。`, 'error');
    } else {
      toast(`每個類別至少需要 ${classMinimum()} 個樣本。`, 'error');
    }
    return;
  }
  stopPreview();
  const options = readTrainingOptions();
  try {
    state.project = await api(`/api/projects/${state.project.id}`, jsonOptions('PATCH', { settings: options }));
    const job = await api(`/api/projects/${state.project.id}/train`, jsonOptions('POST', { options }));
    state.activeJobId = job.id;
    setTrainingProgress(job.progress || 0, job.message || 'Queued');
    renderTrainingPanel();
    pollJob(job.id);
  } catch (error) {
    toast(`無法開始訓練：${error.message}`, 'error');
  }
}

function setTrainingProgress(progress, message) {
  const percent = Math.round((Number(progress) || 0) * 100);
  elements.trainingPercent.textContent = `${percent}%`;
  elements.trainingMessage.textContent = message || 'Training…';
  elements.trainingProgressBar.style.width = `${percent}%`;
  const ring = elements.trainingPercent.closest('.progress-ring');
  if (ring) ring.style.setProperty('--progress', `${percent}%`);
}

function pollJob(jobId) {
  if (state.jobTimer) clearInterval(state.jobTimer);
  state.activeJobId = jobId;
  const tick = async () => {
    try {
      const job = await api(`/api/jobs/${jobId}`);
      setTrainingProgress(job.progress, job.message);
      if (job.state === 'completed') {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        state.activeJobId = null;
        state.project = job.result?.project || await api(`/api/projects/${state.project.id}`);
        renderProject();
        toast(
          isAbnormalSoundProject()
            ? 'YAMNet Normal-only detector 已建立，可立即 Preview 異常分數'
            : '模型訓練完成，可立即 Preview；INT8 會在 Export Model 時產生',
          'success',
        );
      } else if (job.state === 'failed') {
        clearInterval(state.jobTimer);
        state.jobTimer = null;
        state.activeJobId = null;
        await loadProject(state.project.id, { quiet: true });
        toast(`訓練失敗：${job.error || job.message}（請按右上角「下載 Log」）`, 'error');
      }
    } catch (error) {
      clearInterval(state.jobTimer);
      state.jobTimer = null;
      state.activeJobId = null;
      toast(`訓練狀態讀取失敗：${error.message}`, 'error');
    }
  };
  tick();
  state.jobTimer = setInterval(tick, 900);
}

function renderPreviewPanel() {
  const trained = trainingState() === 'trained';
  elements.openExportButton.disabled = !trained;
  elements.previewLocked.classList.toggle('hidden', trained);
  elements.previewReady.classList.toggle('hidden', !trained);
  if (!trained) return;
  const artifacts = state.project.training?.artifacts || {};
  for (const option of [...elements.previewRuntime.options]) {
    if (option.value === 'keras') option.disabled = !artifacts.keras;
    else option.disabled = !artifacts[option.value];
  }
  const selectedOption = elements.previewRuntime.selectedOptions[0];
  if (!selectedOption || selectedOption.disabled) elements.previewRuntime.value = 'keras';
  elements.imagePreviewPane.classList.toggle('hidden', state.project.kind !== 'image');
  elements.audioPreviewPane.classList.toggle('hidden', !isAudioLikeProject());
  clearPreviewOutput();
}


function renderPredictionBars(predictions, result = null) {
  if (!state.project) return;
  const safePredictions = predictions || [];
  const multiLabel = isKnownSoundProject();
  const threshold = multiLabel ? knownSoundThreshold() : null;
  const byName = new Map(safePredictions.map(item => [item.class_name, item.score]));
  const topName = safePredictions.length
    ? [...safePredictions].sort((a, b) => Number(b.score || 0) - Number(a.score || 0))[0].class_name
    : null;
  elements.predictionBars.innerHTML = state.project.classes.map(classItem => {
    const score = Math.max(0, Math.min(1, Number(byName.get(classItem.name) || 0)));
    const width = (score * 100).toFixed(2);
    // For a mutually exclusive softmax the winner is meaningful; for independent
    // sigmoids "above its own threshold" is the meaningful state, and several classes
    // can be in it at once.
    const highlight = multiLabel ? score >= threshold : classItem.name === topName;
    const marker = multiLabel
      ? `<i class="prediction-threshold" style="--prediction-threshold:${(threshold * 100).toFixed(2)}%"></i>`
      : '';
    return `<div class="prediction-row ${highlight ? 'prediction-top' : ''}" style="--prediction-color:${classItem.color}">
      <div class="prediction-meta">
        <span class="prediction-label"><i class="prediction-dot"></i>${escapeHtml(classItem.name)}</span>
        <strong class="prediction-score">${formatPercent(score)}</strong>
      </div>
      <span class="prediction-track" role="progressbar" aria-label="${escapeHtml(classItem.name)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(score * 100)}" aria-valuetext="${formatPercent(score)}">
        <i class="prediction-fill ${score > 0 ? 'has-value' : ''}" style="--prediction-width:${width}%"></i>${marker}
      </span>
    </div>`;
  }).join('');
  if (elements.predictionNote) {
    if (multiLabel) {
      const detected = (result?.detected || []).filter(Boolean);
      elements.predictionNote.innerHTML = `每一類都是獨立分數，<strong>不會加總成 100%</strong>；超過 ${formatPercent(threshold)} 的視為偵測到。這是模型在已知類別上的信心，不是真實機率。`
        + (detected.length ? `<br>目前偵測到：<strong>${detected.map(escapeHtml).join('、')}</strong>` : '');
      elements.predictionNote.classList.remove('hidden');
    } else {
      elements.predictionNote.classList.add('hidden');
    }
  }
}

function clearPreviewOutput() {
  state.knownSoundPeaks = new Map();
  if (isAbnormalSoundProject()) renderAbnormalPrediction(null);
  else renderPredictionBars([]);
}

function finiteNumber(...values) {
  for (const value of values) {
    if (value == null || value === '') continue;
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return null;
}

function componentNumber(value) {
  if (value && typeof value === 'object') {
    return finiteNumber(value.ratio, value.value, value.score, value.distance);
  }
  return finiteNumber(value);
}

function normalizedVerdict(result) {
  const raw = String(result?.verdict || result?.decision || result?.state || '').trim().toLowerCase();
  if (['abnormal', 'anomaly', 'alarm', 'detected'].includes(raw) || result?.abnormal === true) return 'abnormal';
  if (['normal', 'ok', 'healthy'].includes(raw) || result?.abnormal === false) return 'normal';
  return 'uncertain';
}

function anomalyComponentEntries(result) {
  const components = result?.components && typeof result.components === 'object' ? result.components : {};
  const preferred = [
    ['embedding', 'YAMNet embedding'],
    ['embedding_ratio', 'YAMNet embedding'],
    ['yamnet_ratio', 'YAMNet embedding'],
    ['distance_ratio', 'Embedding distance'],
    ['level', 'RMS level'],
    ['level_ratio', 'RMS level'],
    ['rms_ratio', 'RMS level'],
  ];
  const entries = [];
  const seenLabels = new Set();
  for (const [key, label] of preferred) {
    const value = componentNumber(components[key] ?? result?.[key]);
    if (value == null || seenLabels.has(label)) continue;
    entries.push([label, value]);
    seenLabels.add(label);
  }
  for (const [key, raw] of Object.entries(components)) {
    const value = componentNumber(raw);
    if (value == null || preferred.some(([preferredKey]) => preferredKey === key)) continue;
    const label = key.replaceAll('_', ' ').replace(/\b\w/g, letter => letter.toUpperCase());
    entries.push([label, value]);
  }
  return entries;
}

function smoothingText(result) {
  const smoothing = result?.smoothing;
  if (!smoothing || typeof smoothing !== 'object') return '';
  if (smoothing.warming_up || smoothing.state === 'warming_up') {
    const observed = finiteNumber(smoothing.observed_windows, smoothing.windows_seen, 0);
    const windowCount = finiteNumber(smoothing.window_count, smoothing.required_windows);
    return windowCount == null ? 'Temporal vote warming up' : `Temporal vote warming up · ${observed}/${windowCount} windows`;
  }
  const votes = finiteNumber(smoothing.votes, smoothing.abnormal_votes, smoothing.exceedances);
  const required = finiteNumber(smoothing.votes_required, smoothing.required_votes);
  const windowCount = finiteNumber(smoothing.window_count, smoothing.windows);
  if (votes == null) {
    return required != null && windowCount != null ? `Temporal policy ${required}-of-${windowCount}` : '';
  }
  return `Temporal vote ${votes}${required == null ? '' : `/${required}`}${windowCount == null ? '' : ` in ${windowCount} windows`}`;
}

function resetAbnormalTemporalSmoothing() {
  state.abnormalPreviewVotes = [];
}

function temporalPolicy(result) {
  const smoothing = result?.smoothing && typeof result.smoothing === 'object' ? result.smoothing : {};
  const presetName = String(state.project?.settings?.sensitivity || 'balanced');
  const presetFallback = presetName === 'sensitive'
    ? { votesRequired: 2, windowCount: 5 }
    : { votesRequired: 3, windowCount: 5 };
  const windowCount = Math.max(1, Math.round(finiteNumber(smoothing.window_count, smoothing.windows, presetFallback.windowCount)));
  const votesRequired = Math.max(1, Math.min(
    windowCount,
    Math.round(finiteNumber(smoothing.votes_required, smoothing.required_votes, presetFallback.votesRequired)),
  ));
  return { smoothing, windowCount, votesRequired };
}

function applyAbnormalTemporalSmoothing(result) {
  const ratio = finiteNumber(result?.anomaly_ratio, result?.composite_ratio, result?.ratio, result?.score);
  const threshold = finiteNumber(result?.threshold, result?.threshold_ratio, 1) || 1;
  const { smoothing, windowCount, votesRequired } = temporalPolicy(result);
  const confidence = String(
    result?.confidence || result?.calibration_confidence || result?.readiness?.confidence || '',
  ).trim().toLowerCase();
  const calibrated = confidence === 'calibrated';
  if (ratio == null) {
    return {
      ...result,
      verdict: 'uncertain',
      smoothing: {
        ...smoothing,
        source: 'browser_sliding_vote',
        warming_up: true,
        observed_windows: state.abnormalPreviewVotes.length,
        abnormal_votes: state.abnormalPreviewVotes.filter(Boolean).length,
        votes_required: votesRequired,
        window_count: windowCount,
      },
    };
  }
  state.abnormalPreviewVotes.push(ratio > threshold);
  if (state.abnormalPreviewVotes.length > windowCount) state.abnormalPreviewVotes.shift();
  const abnormalVotes = state.abnormalPreviewVotes.filter(Boolean).length;
  const warmedUp = state.abnormalPreviewVotes.length >= windowCount;
  return {
    ...result,
    verdict: calibrated && warmedUp
      ? (abnormalVotes >= votesRequired ? 'abnormal' : 'normal')
      : 'uncertain',
    smoothing: {
      ...smoothing,
      source: 'browser_sliding_vote',
      state: warmedUp ? 'ready' : 'warming_up',
      warming_up: !warmedUp,
      observed_windows: state.abnormalPreviewVotes.length,
      abnormal_votes: abnormalVotes,
      votes: abnormalVotes,
      votes_required: votesRequired,
      window_count: windowCount,
      calibration_ready: calibrated,
    },
  };
}

function renderAbnormalPrediction(result) {
  if (!state.project) return;
  if (!result) {
    elements.predictionBars.innerHTML = `
      <div class="anomaly-result verdict-uncertain empty">
        <div class="anomaly-verdict"><i></i><span><strong>Waiting for audio</strong><small>YAMNet embedding distance and RMS level will appear here.</small></span></div>
      </div>`;
    return;
  }
  const verdict = normalizedVerdict(result);
  const verdictLabels = {
    normal: ['Normal', 'Within the collected Normal baseline'],
    abnormal: ['Abnormal', 'Outside the calibrated Normal baseline'],
    uncertain: ['Uncertain', 'Warming up or calibration evidence is insufficient'],
  };
  const verdictDetail = result.message || verdictLabels[verdict][1];
  const ratio = finiteNumber(result.anomaly_ratio, result.composite_ratio, result.ratio, result.score);
  const threshold = finiteNumber(result.threshold, result.threshold_ratio, 1) || 1;
  const ratioText = ratio == null ? '—' : `${ratio.toFixed(2)}×`;
  const gaugeWidth = ratio == null ? 0 : Math.max(0, Math.min(100, ratio / Math.max(threshold * 2, 0.000001) * 100));
  const components = anomalyComponentEntries(result);
  const componentHtml = components.length
    ? `<div class="anomaly-components">${components.map(([label, value]) => `
        <div><span>${escapeHtml(label)}</span><strong>${value.toFixed(2)}×</strong></div>`).join('')}</div>`
    : '';
  const confidence = result.confidence || result.calibration_confidence || result.readiness?.confidence;
  const smoothing = smoothingText(result);
  elements.predictionBars.innerHTML = `
    <div class="anomaly-result verdict-${verdict}">
      <div class="anomaly-verdict"><i></i><span><strong>${verdictLabels[verdict][0]}</strong><small>${escapeHtml(verdictDetail)}</small></span></div>
      <div class="anomaly-ratio-row"><span>Anomaly ratio</span><strong>${ratioText}</strong></div>
      <div class="anomaly-gauge" role="meter" aria-label="Anomaly ratio" aria-valuemin="0" aria-valuemax="${threshold * 2}" aria-valuenow="${ratio ?? 0}">
        <i style="--anomaly-width:${gaugeWidth.toFixed(2)}%"></i><b title="Threshold ${threshold.toFixed(2)}×"></b>
      </div>
      <small class="anomaly-threshold-copy">Threshold ${threshold.toFixed(2)}× · values above the marker are anomalous</small>
      ${componentHtml}
      ${(confidence || smoothing) ? `<div class="anomaly-footnote">${confidence ? `Calibration: ${escapeHtml(confidence)}` : ''}${confidence && smoothing ? ' · ' : ''}${escapeHtml(smoothing)}</div>` : ''}
    </div>`;
}

async function togglePreview() {
  if (elements.previewInputToggle.checked) await startPreview();
  else stopPreview();
}

async function startPreview() {
  if (!state.project || trainingState() !== 'trained') return;
  if (isAbnormalSoundProject()) {
    state.previewSessionId = newRecordingSessionId();
    resetAbnormalTemporalSmoothing();
  }
  elements.previewToggleText.textContent = 'ON';
  if (state.project.kind === 'image') {
    try {
      elements.previewVideo.srcObject = await ensureCamera();
      await elements.previewVideo.play().catch(() => {});
      state.previewTimer = setInterval(predictCameraFrame, 450);
      predictCameraFrame();
    } catch (error) {
      elements.previewInputToggle.checked = false;
      toast(`無法啟動預覽相機：${error.message}`, 'error');
    }
  } else {
    try {
      await ensureAudio();
      $('.audio-live-status').classList.add('active');
      elements.audioLiveText.textContent = 'Listening…';
      state.previewTimer = setInterval(predictRecentAudio, 500);
      setTimeout(predictRecentAudio, 800);
    } catch (error) {
      elements.previewInputToggle.checked = false;
      toast(`無法啟動預覽麥克風：${error.message}`, 'error');
    }
  }
}

function stopPreview() {
  if (state.previewTimer) clearInterval(state.previewTimer);
  state.previewTimer = null;
  state.previewBusy = false;
  state.previewSessionId = null;
  resetAbnormalTemporalSmoothing();
  if (elements.previewInputToggle) elements.previewInputToggle.checked = false;
  if (elements.previewToggleText) elements.previewToggleText.textContent = 'OFF';
  const status = $('.audio-live-status');
  status?.classList.remove('active');
  if (elements.audioLiveText) elements.audioLiveText.textContent = 'Microphone is off';
}

async function predictCameraFrame() {
  const video = elements.previewVideo;
  if (!video.videoWidth || state.previewBusy) return;
  const canvas = elements.previewCanvas;
  const context = canvas.getContext('2d');
  const side = Math.min(video.videoWidth, video.videoHeight);
  const x = (video.videoWidth - side) / 2;
  const y = (video.videoHeight - side) / 2;
  context.drawImage(video, x, y, side, side, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.88));
  if (blob) await predictBlob(blob, 'image/jpeg', 'preview.jpg', 'image');
}

async function predictRecentAudio() {
  const minimumSeconds = isAbnormalSoundProject() ? 1.0 : 0.5;
  if (!state.audioContext || state.previewBusy || state.audioRollingSamples < state.audioContext.sampleRate * minimumSeconds) return;
  const signal = recentAudio(1.0);
  const blob = encodeWavBlob(signal, state.audioContext.sampleRate);
  await predictBlob(blob, 'audio/wav', 'preview.wav', 'audio');
}

async function predictBlob(blob, type, filename, kind) {
  state.previewBusy = true;
  try {
    const data = new FormData();
    data.append('file', new File([blob], filename, { type }), filename);
    data.append('runtime_name', elements.previewRuntime.value);
    if (isAbnormalSoundProject()) {
      state.previewSessionId ||= newRecordingSessionId();
      data.append('preview_session_id', state.previewSessionId);
    }
    let endpointKind = kind;
    if (kind === 'audio' && isAbnormalSoundProject()) endpointKind = 'abnormal-sound';
    else if (kind === 'audio' && isKnownSoundProject()) endpointKind = 'known-sound';
    const result = await api(`/api/projects/${state.project.id}/predict/${endpointKind}`, { method: 'POST', body: data });
    if (isAbnormalSoundProject()) renderAbnormalPrediction(applyAbnormalTemporalSmoothing(result));
    else if (isKnownSoundProject()) renderPredictionBars(applyKnownSoundPeakHold(result.predictions), result);
    else renderPredictionBars(result.predictions);
  } catch (error) {
    stopPreview();
    toast(`預覽失敗：${error.message}`, 'error');
  } finally {
    state.previewBusy = false;
  }
}

async function previewImageFile(file) {
  if (!file) return;
  const image = new Image();
  image.onload = () => {
    const canvas = elements.previewCanvas;
    const context = canvas.getContext('2d');
    const side = Math.min(image.naturalWidth, image.naturalHeight);
    context.drawImage(image, (image.naturalWidth - side) / 2, (image.naturalHeight - side) / 2, side, side, 0, 0, canvas.width, canvas.height);
    URL.revokeObjectURL(image.src);
  };
  image.src = URL.createObjectURL(file);
  await predictBlob(file, file.type || 'image/jpeg', file.name || 'preview.jpg', 'image');
}

async function previewAudioFile(file) {
  if (!file) return;
  setBusy(true, '解碼預覽音訊…');
  try {
    const Context = window.AudioContext || window.webkitAudioContext;
    const context = new Context();
    const decoded = await context.decodeAudioData((await file.arrayBuffer()).slice(0));
    await context.close();
    const mono = mixAudioBufferToMono(decoded);
    const blob = encodeWavBlob(mono, decoded.sampleRate);
    await predictBlob(blob, 'audio/wav', 'preview.wav', 'audio');
  } catch (error) {
    toast(`音訊預覽失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function stopAllMedia() {
  stopPreview();
  if (state.imageCaptureTimer) clearInterval(state.imageCaptureTimer);
  state.imageCaptureTimer = null;
  if (state.audioRecordTimer) clearInterval(state.audioRecordTimer);
  state.audioRecordTimer = null;
  state.audioRecording = false;
  state.audioRecordingClassId = null;
  state.audioRecordingSessionId = null;
  state.imageCaptureClassId = null;
  state.cameraStream?.getTracks().forEach(track => track.stop());
  state.cameraStream = null;
  await releaseAudioInput();
  $('#stopMediaButton').classList.add('hidden');
  toast('相機與麥克風已停止');
}

function openExportModal() {
  if (trainingState() !== 'trained') return;
  $('#exportModal').classList.remove('hidden');
}

async function downloadModel() {
  const selected = $$('input[name="exportFormat"]:checked').map(input => input.value);
  if (!selected.length) {
    toast('請至少選擇一種模型格式。', 'error');
    return;
  }
  $('#exportModal').classList.add('hidden');
  try {
    const job = await api(
      `/api/projects/${state.project.id}/export-model`,
      jsonOptions('POST', {
        formats: selected,
        include_c_header: $('#includeCHeader').checked,
      }),
    );
    state.activeExportJobId = job.id;
    state.exportStartedAt = Date.now();
    setBusy(true, '準備模型匯出… 0%');
    pollExportJob(job.id);
  } catch (error) {
    setBusy(false);
    toast(`模型匯出失敗：${error.message}`, 'error');
  }
}

function exportElapsedText() {
  const elapsed = Math.max(0, Math.floor((Date.now() - state.exportStartedAt) / 1000));
  const minutes = Math.floor(elapsed / 60);
  const seconds = String(elapsed % 60).padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function pollExportJob(jobId) {
  if (state.exportJobTimer) clearInterval(state.exportJobTimer);
  const tick = async () => {
    try {
      const job = await api(`/api/jobs/${jobId}`);
      const percent = Math.round((Number(job.progress) || 0) * 100);
      setBusy(true, `模型匯出 ${percent}% · ${job.message || '處理中…'} · 已經 ${exportElapsedText()}`);
      if (job.state === 'completed') {
        clearInterval(state.exportJobTimer);
        state.exportJobTimer = null;
        state.activeExportJobId = null;
        const result = job.result || {};
        if (result.project) {
          state.project = result.project;
          renderProject();
        } else {
          await loadProject(state.project.id, { quiet: true });
        }
        const response = await api(result.download_url);
        await downloadResponse(response, result.filename || `${state.project.name}_TFLite.zip`);
        setBusy(false);
        toast('模型轉換完成，ZIP 已下載；INT8／UINT8 現在也可在 Preview 選擇', 'success');
      } else if (job.state === 'failed') {
        clearInterval(state.exportJobTimer);
        state.exportJobTimer = null;
        state.activeExportJobId = null;
        setBusy(false);
        toast(`模型匯出失敗：${job.error || job.message}（請按右上角「下載 Log」）`, 'error');
      }
    } catch (error) {
      clearInterval(state.exportJobTimer);
      state.exportJobTimer = null;
      state.activeExportJobId = null;
      setBusy(false);
      toast(`模型匯出狀態讀取失敗：${error.message}`, 'error');
    }
  };
  tick();
  state.exportJobTimer = setInterval(tick, 900);
}


function downloadDiagnostics() {
  const link = document.createElement('a');
  link.href = `/api/diagnostics/download?ts=${Date.now()}`;
  link.download = 'TM_Local_Studio_Diagnostic.txt';
  document.body.appendChild(link);
  link.click();
  link.remove();
  toast('診斷 Log 已下載；發生問題時把這個檔案傳給負責人。', 'success');
}

async function downloadProject() {
  if (!state.project) return;
  setBusy(true, '封裝完整專案與樣本…');
  try {
    const response = await api(`/api/projects/${state.project.id}/export-project`);
    await downloadResponse(response, `${state.project.name}_Project.zip`);
  } catch (error) {
    toast(`專案下載失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function downloadResponse(response, fallbackName) {
  const blob = await response.blob();
  const disposition = response.headers.get('content-disposition') || '';
  const match = disposition.match(/filename\*?=(?:UTF-8''|"?)([^";]+)/i);
  const filename = match ? decodeURIComponent(match[1].replaceAll('"', '')) : fallbackName;
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function importProject(file) {
  if (!file) return;
  setBusy(true, '匯入專案…');
  try {
    const data = new FormData();
    data.append('file', file, file.name);
    const project = await api('/api/projects/import', { method: 'POST', body: data });
    toast('專案已匯入', 'success');
    goProject(project.id);
  } catch (error) {
    toast(`專案匯入失敗：${error.message}`, 'error');
  } finally {
    setBusy(false);
    $('#importProjectInput').value = '';
  }
}

function confirmDialog(title, message) {
  $('#confirmTitle').textContent = title;
  $('#confirmMessage').textContent = message;
  $('#confirmModal').classList.remove('hidden');
  return new Promise(resolve => { state.confirmResolver = resolve; });
}

function resolveConfirm(value) {
  $('#confirmModal').classList.add('hidden');
  state.confirmResolver?.(value);
  state.confirmResolver = null;
}

function drawConnectors() {
  if (!state.project || elements.projectView.classList.contains('hidden')) return;
  const canvas = $('#workspaceCanvas');
  const canvasRect = canvas.getBoundingClientRect();
  const width = canvas.scrollWidth;
  const height = Math.max(canvas.scrollHeight, canvas.clientHeight);
  elements.connectorSvg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  elements.connectorSvg.setAttribute('width', width);
  elements.connectorSvg.setAttribute('height', height);
  elements.connectorSvg.innerHTML = '';
  const training = $('#trainingCard').getBoundingClientRect();
  const preview = $('#previewCard').getBoundingClientRect();
  const scrollX = canvas.scrollLeft;
  const scrollY = canvas.scrollTop;
  const point = rect => ({
    left: rect.left - canvasRect.left + scrollX,
    right: rect.right - canvasRect.left + scrollX,
    top: rect.top - canvasRect.top + scrollY,
    bottom: rect.bottom - canvasRect.top + scrollY,
    midY: (rect.top + rect.bottom) / 2 - canvasRect.top + scrollY,
  });
  const trainPoint = point(training);
  for (const card of $$('.class-card')) {
    const from = point(card.getBoundingClientRect());
    addConnector(from.right, from.midY, trainPoint.left, trainPoint.midY);
  }
  const previewPoint = point(preview);
  addConnector(trainPoint.right, trainPoint.midY, previewPoint.left, previewPoint.midY);
}

function addConnector(x1, y1, x2, y2) {
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  const distance = Math.max(25, (x2 - x1) * 0.48);
  path.setAttribute('d', `M ${x1} ${y1} C ${x1 + distance} ${y1}, ${x2 - distance} ${y2}, ${x2} ${y2}`);
  elements.connectorSvg.appendChild(path);
}

function wireGlobalEvents() {
  $$('[data-create-kind]').forEach(button => button.addEventListener('click', () => createProject(button.dataset.createKind)));
  $('#homeButton').addEventListener('click', goHome);
  $('#refreshProjectsButton').addEventListener('click', loadProjects);
  $('#reloadProjectButton').addEventListener('click', () => state.project && loadProject(state.project.id));
  $('#addClassButton').addEventListener('click', async () => {
    try {
      state.project = await api(`/api/projects/${state.project.id}/classes`, jsonOptions('POST', {}));
      renderProject();
    } catch (error) { toast(`新增類別失敗：${error.message}`, 'error'); }
  });
  elements.projectNameInput.addEventListener('change', async () => {
    if (!state.project) return;
    const name = elements.projectNameInput.value.trim() || state.project.name;
    elements.saveState.textContent = '儲存中…';
    try {
      state.project = await api(`/api/projects/${state.project.id}`, jsonOptions('PATCH', { name }));
      elements.saveState.textContent = '已儲存於本機';
      document.title = `${state.project.name} · Teachable Machine Local`;
    } catch (error) {
      elements.projectNameInput.value = state.project.name;
      elements.saveState.textContent = '儲存失敗';
      toast(error.message, 'error');
    }
  });
  elements.projectNameInput.addEventListener('keydown', event => { if (event.key === 'Enter') elements.projectNameInput.blur(); });
  elements.trainButton.addEventListener('click', startTraining);
  $('#retrainButton').addEventListener('click', startTraining);
  elements.previewInputToggle.addEventListener('change', togglePreview);
  elements.previewRuntime.addEventListener('change', () => {
    clearPreviewOutput();
    if (elements.previewInputToggle.checked) {
      stopPreview();
      elements.previewInputToggle.checked = true;
      startPreview();
    }
  });
  $('#previewImageInput').addEventListener('change', event => previewImageFile(event.target.files?.[0]));
  $('#previewAudioInput').addEventListener('change', event => previewAudioFile(event.target.files?.[0]));
  elements.microphoneDeviceSelect.addEventListener('change', selectMicrophoneDevice);
  $('#refreshMicrophonesButton').addEventListener('click', () => refreshMicrophoneDevices());
  elements.openExportButton.addEventListener('click', openExportModal);
  $('#downloadModelButton').addEventListener('click', downloadModel);
  $$('[data-close-modal]').forEach(button => button.addEventListener('click', () => $(`#${button.dataset.closeModal}`).classList.add('hidden')));
  $('#confirmCancel').addEventListener('click', () => resolveConfirm(false));
  $('#confirmAccept').addEventListener('click', () => resolveConfirm(true));
  $('#importProjectButton').addEventListener('click', () => $('#importProjectInput').click());
  $('#importProjectInput').addEventListener('change', event => importProject(event.target.files?.[0]));
  $('#exportProjectButton').addEventListener('click', downloadProject);
  $('#downloadDiagnosticsButton').addEventListener('click', downloadDiagnostics);
  $('#deleteProjectButton').addEventListener('click', async () => {
    if (!state.project) return;
    const ok = await confirmDialog('刪除專案', `確定刪除「${state.project.name}」與所有本機樣本嗎？`);
    if (!ok) return;
    setBusy(true, '刪除專案…');
    try {
      await api(`/api/projects/${state.project.id}`, { method: 'DELETE' });
      await stopAllMedia();
      goHome();
    } catch (error) { toast(error.message, 'error'); }
    finally { setBusy(false); }
  });
  $('#stopMediaButton').addEventListener('click', stopAllMedia);
  window.addEventListener('hashchange', handleRoute);
  window.addEventListener('resize', drawConnectors);
  navigator.mediaDevices?.addEventListener?.('devicechange', () => refreshMicrophoneDevices({ silent: true }));
  document.addEventListener('click', event => {
    if (!event.target.closest('.class-menu-button') && !event.target.closest('.class-action-menu')) {
      $$('.class-action-menu').forEach(menu => menu.classList.add('hidden'));
    }
  });
}

async function boot() {
  state.audioDeviceId = readSavedMicrophoneId();
  wireGlobalEvents();
  await checkHealth();
  await handleRoute();
  setInterval(checkHealth, 15000);
}

boot();
