from __future__ import annotations

import subprocess
import shutil
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_required_distribution_files_exist() -> None:
    required = [
        "01_INSTALL.bat",
        "02_START.bat",
        "README_zh-TW.md",
        "requirements.txt",
        "scripts/install_local.py",
        "scripts/verify_install.py",
        "scripts/prefetch_assets.py",
        "tm_local/yamnet_model.py",
        "tm_local/yamnet_anomaly_pipeline.py",
        "tm_local/known_sound_pipeline.py",
        "docs/ABNORMAL_SOUND_YAMNET_zh-TW.md",
        "docs/KNOWN_SOUND_zh-TW.md",
        "web/index.html",
        "web/app.js",
        "web/style.css",
    ]
    missing = [name for name in required if not (ROOT / name).is_file()]
    assert not missing


def test_distribution_exposes_only_two_student_bat_files() -> None:
    relative_names = sorted(
        str(path.relative_to(ROOT)).replace("/", "\\")
        for path in ROOT.rglob("*.bat")
        if ".venv" not in path.parts
    )
    assert relative_names == ["01_INSTALL.bat", "02_START.bat"]


def test_distribution_uses_project_venv() -> None:
    bats = "\n".join(path.read_text(encoding="utf-8", errors="ignore") for path in ROOT.glob("*.bat"))
    assert ".venv\\Scripts\\python.exe" in bats
    assert "conda activate" not in bats.lower()
    assert "Python 3.13" in (ROOT / "01_INSTALL.bat").read_text(encoding="utf-8")


def test_installer_is_native_windows_cpu_only() -> None:
    installer = (ROOT / "scripts/install_local.py").read_text(encoding="utf-8")
    dispatch = (ROOT / "tm_local/training_dispatch.py").read_text(encoding="utf-8")
    runtime = (ROOT / "tm_local/runtime_config.py").read_text(encoding="utf-8")
    combined = "\n".join((installer, dispatch, runtime))
    assert "windows_tensorflow_cpu" in combined
    assert "Windows CPU" in combined
    assert "wsl.exe" not in combined
    assert "wsl --install" not in combined
    assert "tensorflow[and-cuda]" not in combined
    assert "nvidia-smi" not in combined
    assert not (ROOT / "requirements-wsl-gpu.txt").exists()
    assert not (ROOT / "scripts/training_worker.py").exists()
    assert not (ROOT / "docs/GPU_SETUP_zh-TW.md").exists()


def test_web_contains_image_audio_training_preview_and_int8_export() -> None:
    html = (ROOT / "web/index.html").read_text(encoding="utf-8")
    js = (ROOT / "web/app.js").read_text(encoding="utf-8")
    for term in ("Image Project", "Audio Project", "Train Model", "Preview", "Quantized INT8"):
        assert term in html
    assert "Abnormal Sound Project" in html
    assert "frozen YAMNet 1024-D embedding" in html
    for term in ("getUserMedia", "predictCameraFrame", "predictRecentAudio", "downloadModel"):
        assert term in js
    assert "下載 Log" in html
    assert "/api/diagnostics/download" in js
    assert "/predict/${endpointKind}" in js


def test_abnormal_sound_has_explicit_dispatch_route_and_pinned_asset() -> None:
    app_source = (ROOT / "tm_local/app.py").read_text(encoding="utf-8")
    dispatch = (ROOT / "tm_local/training_dispatch.py").read_text(encoding="utf-8")
    asset = (ROOT / "tm_local/yamnet_model.py").read_text(encoding="utf-8")
    assert '@app.post("/api/projects/{project_id}/predict/abnormal-sound")' in app_source
    assert 'normalized_kind == "abnormal_sound"' in dispatch
    assert "train_yamnet_abnormal_sound_project" in dispatch
    assert "13c3308955bbfaef262f175ac9c40e47b134573a93984f009220dd7cc12a1744" in asset


def test_known_sound_has_explicit_dispatch_route_and_multi_label_contract() -> None:
    """The fourth kind must be routed explicitly, never via an implicit else branch."""
    app_source = (ROOT / "tm_local/app.py").read_text(encoding="utf-8")
    dispatch = (ROOT / "tm_local/training_dispatch.py").read_text(encoding="utf-8")
    pipeline = (ROOT / "tm_local/known_sound_pipeline.py").read_text(encoding="utf-8")
    config_source = (ROOT / "tm_local/config.py").read_text(encoding="utf-8")
    store_source = (ROOT / "tm_local/project_store.py").read_text(encoding="utf-8")

    assert '@app.post("/api/projects/{project_id}/predict/known-sound")' in app_source
    assert '@app.post("/api/projects/{project_id}/audio-sanity")' in app_source
    assert 'normalized_kind == "known_sound"' in dispatch
    assert "train_known_sound_project" in dispatch

    # Registered in the kind registry rather than bolted on with string comparisons.
    assert '"known_sound"' in config_source
    assert "KNOWN_SOUND_DEFAULTS" in config_source
    assert "MULTI_LABEL_KINDS" in config_source
    # create_project must branch explicitly; an implicit else silently made every unknown
    # kind an abnormal_sound project.
    assert 'elif kind == "known_sound":' in store_source
    assert 'elif kind == "abnormal_sound":' in store_source

    # The class map is a DOWNLOADED asset like yamnet.h5, so it is pinned by digest in
    # both the installer and the loader rather than shipped in the repo.
    prefetch = (ROOT / "scripts/prefetch_assets.py").read_text(encoding="utf-8")
    asset = (ROOT / "tm_local/yamnet_model.py").read_text(encoding="utf-8")
    class_map_sha = "cdf24d193e196d9e95912a2667051ae203e92a2ba09449218ccb40ef787c6df2"
    assert class_map_sha in prefetch
    assert class_map_sha in asset
    assert "yamnet_class_map.csv" in prefetch

    # Multi-label, not softmax: independent sigmoids that must not be called probabilities.
    assert 'activation="sigmoid"' in pipeline
    assert 'loss="binary_crossentropy"' in pipeline
    assert "softmax" not in pipeline
    # Train must not convert to TFLite, and conversion must not use from_keras_model.
    assert "convert_all(" not in pipeline
    assert "from_keras_model(" not in pipeline
    # The encoder stays frozen; fine-tuning 3.2M parameters on a few clips is not the
    # design. This pins the MECHANISM -- every layer but the head is frozen. The behaviour
    # itself is asserted in test_known_sound.py by counting trainable parameters.
    assert 'if layer.name != "class_scores":' in pipeline
    assert "layer.trainable = False" in pipeline


def test_known_sound_split_is_session_disjoint_not_clip_level() -> None:
    """The leakage fix is the whole point of the kind; lock it against a 'tidy' rewrite."""
    pipeline = (ROOT / "tm_local/known_sound_pipeline.py").read_text(encoding="utf-8")
    assert "def split_sessions(" in pipeline
    assert "recording_session_id" in pipeline
    # stratified_path_split is the clip-level splitter that causes the leakage.
    assert "stratified_path_split" not in pipeline


def test_web_offers_known_sound_project_with_independent_scores() -> None:
    html = (ROOT / "web/index.html").read_text(encoding="utf-8")
    js = (ROOT / "web/app.js").read_text(encoding="utf-8")
    assert 'data-create-kind="known_sound"' in html
    assert "Known Sound Project" in html
    assert "isKnownSoundProject" in js
    assert "applyKnownSoundPeakHold" in js
    assert "runAudioSanityCheck" in js
    assert "/audio-sanity" in js
    # The UI must state that the scores are independent and do not total 100%.
    assert "不會加總成 100%" in js


def test_prediction_percentage_bars_have_visible_block_fill() -> None:
    css = (ROOT / "web/style.css").read_text(encoding="utf-8")
    js = (ROOT / "web/app.js").read_text(encoding="utf-8")
    assert ".prediction-fill { display:block;" in css
    assert "--prediction-width" in css
    assert "prediction-meta" in js
    assert "prediction-score" in js


def test_javascript_syntax_when_node_is_available() -> None:
    if shutil.which("node") is None:
        return
    result = subprocess.run(
        ["node", "--check", str(ROOT / "web/app.js")],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr


def test_startup_does_not_use_fragile_app_string_import() -> None:
    source = (ROOT / "scripts/start_local.py").read_text(encoding="utf-8")
    assert 'uvicorn.run("app:app"' not in source
    assert "sys.path.insert(0, str(PROJECT_ROOT))" in source
    assert "application = _create_application()" in source
    assert "uvicorn.run(\n            application," in source
    assert "setup_session_logging" in source
    assert "/?session={time_ns()}" in source


def test_startup_import_check_works_from_unrelated_working_directory(tmp_path: Path) -> None:
    result = subprocess.run(
        [sys.executable, str(ROOT / "scripts/start_local.py"), "--check"],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "[PASS] Local Studio application import/create check" in result.stdout


def test_training_defers_tflite_until_export_and_converter_uses_saved_model() -> None:
    image_source = (ROOT / "tm_local/image_pipeline.py").read_text(encoding="utf-8")
    audio_source = (ROOT / "tm_local/audio_pipeline.py").read_text(encoding="utf-8")
    export_source = (ROOT / "tm_local/tflite_export.py").read_text(encoding="utf-8")
    app_source = (ROOT / "tm_local/app.py").read_text(encoding="utf-8")
    assert "convert_all(" not in image_source
    assert "convert_all(" not in audio_source
    assert "from_keras_model(" not in export_source
    assert "TFLiteConverter.from_saved_model" in export_source
    assert '@app.post("/api/projects/{project_id}/export-model")' in app_source
    assert "conversion_worker" in (ROOT / "tm_local/export_service.py").read_text(encoding="utf-8")


def test_single_diagnostic_download_includes_runtime_and_both_latest_logs() -> None:
    source = (ROOT / "tm_local/diagnostics.py").read_text(encoding="utf-8")
    assert "runtime_config" in source
    assert "LATEST.log" in source
    assert "LATEST_INSTALL.log" in source
    assert "no images/audio included" in source

def test_windows_batch_entry_points_are_ascii_crlf() -> None:
    for name in ("01_INSTALL.bat", "02_START.bat"):
        payload = (ROOT / name).read_bytes()
        assert not payload.startswith(b"\xef\xbb\xbf")
        payload.decode("ascii")
        assert b"\r\n" in payload
        assert b"\n" not in payload.replace(b"\r\n", b"")
