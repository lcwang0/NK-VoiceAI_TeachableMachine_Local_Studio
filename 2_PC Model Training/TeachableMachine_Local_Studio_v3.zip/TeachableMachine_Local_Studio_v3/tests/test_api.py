from __future__ import annotations

from fastapi.testclient import TestClient

from tm_local.app import create_app
from tm_local.jobs import JobManager
from tm_local.model_runtime import ModelRuntime
from tm_local.project_store import ProjectStore


def make_client(store: ProjectStore) -> TestClient:
    return TestClient(create_app(store=store, jobs=JobManager(max_workers=1), runtime=ModelRuntime()))


def test_frontend_assets_are_not_cached(store: ProjectStore) -> None:
    with make_client(store) as client:
        for path in ("/", "/index.html", "/app.js", "/style.css"):
            response = client.get(path)
            assert response.status_code == 200
            assert response.headers["cache-control"] == "no-store, no-cache, must-revalidate, max-age=0"


def test_health_and_project_crud(store: ProjectStore) -> None:
    with make_client(store) as client:
        health = client.get("/api/health")
        assert health.status_code == 200
        assert health.json()["status"] == "ok"
        created = client.post("/api/projects", json={"kind": "image", "name": "API Image"})
        assert created.status_code == 200
        project = created.json()
        fetched = client.get(f"/api/projects/{project['id']}")
        assert fetched.status_code == 200
        assert fetched.json()["name"] == "API Image"
        renamed = client.patch(f"/api/projects/{project['id']}", json={"name": "Renamed"})
        assert renamed.json()["name"] == "Renamed"
        deleted = client.delete(f"/api/projects/{project['id']}")
        assert deleted.json() == {"ok": True}


def test_image_and_audio_upload_api(store: ProjectStore, jpeg_bytes: bytes, wav_bytes: bytes) -> None:
    with make_client(store) as client:
        image = client.post("/api/projects", json={"kind": "image"}).json()
        image_class = image["classes"][0]["id"]
        response = client.post(
            f"/api/projects/{image['id']}/classes/{image_class}/images",
            files=[("files", ("sample.jpg", jpeg_bytes, "image/jpeg"))],
        )
        assert response.status_code == 200
        assert response.json()["added"] == 1

        audio = client.post("/api/projects", json={"kind": "audio"}).json()
        audio_class = audio["classes"][0]["id"]
        response = client.post(
            f"/api/projects/{audio['id']}/classes/{audio_class}/audio",
            files=[("files", ("tone.wav", wav_bytes, "audio/wav"))],
            data={"overlap": "0"},
        )
        assert response.status_code == 200
        assert response.json()["added"] == 2


def test_async_export_job_and_one_time_download(store: ProjectStore, monkeypatch) -> None:  # noqa: ANN001
    import time
    import zipfile
    from pathlib import Path

    from tm_local import app as app_module

    project = store.create_project("image", "Export API")
    models = store.project_dir(project["id"]) / "models"
    keras_path = models / "image_classifier.keras"
    keras_path.write_bytes(b"fake keras")
    store.set_training_result(
        project["id"],
        report={
            "settings": {"image_size": 224},
            "dataset": {"calibration_samples": 0},
            "evaluation": {},
            "conversion": {"state": "pending", "models": {}},
        },
        artifacts={"keras": keras_path.name},
    )

    def fake_export(*, store, project_id, selected, include_c_header, output_zip, progress):  # noqa: ANN001
        progress(0.2, "Converting…")
        with zipfile.ZipFile(output_zip, "w") as archive:
            archive.writestr("model.tflite", b"TFL3")
        progress(1.0, "Ready")
        return {
            "project": store.get_project(project_id),
            "formats": list(selected),
            "calibration_samples": 2,
        }

    monkeypatch.setattr(app_module, "create_model_export", fake_export)
    with make_client(store) as client:
        started = client.post(
            f"/api/projects/{project['id']}/export-model",
            json={"formats": ["int8"], "include_c_header": True},
        )
        assert started.status_code == 200
        job_id = started.json()["id"]
        job = None
        for _ in range(100):
            job = client.get(f"/api/jobs/{job_id}").json()
            if job["state"] in {"completed", "failed"}:
                break
            time.sleep(0.01)
        assert job and job["state"] == "completed", job
        url = job["result"]["download_url"]
        downloaded = client.get(url)
        assert downloaded.status_code == 200
        assert downloaded.content.startswith(b"PK")
        assert client.get(url).status_code == 404
