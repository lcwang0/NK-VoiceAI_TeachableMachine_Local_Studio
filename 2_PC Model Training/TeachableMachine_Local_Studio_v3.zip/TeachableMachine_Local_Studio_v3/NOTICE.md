# Notice

Teachable Machine Local Studio is an independent local implementation created for education and local model deployment. It is not sponsored, endorsed, maintained by, or affiliated with Google.

“Teachable Machine”, “TensorFlow”, “Google”, and related marks belong to their respective owners. The descriptive project title is used to explain compatibility and the familiar workflow. This package does not include Google logos, proprietary artwork, Google account integration, cloud storage, telemetry, or the official hosted application.

Portions of the design approach were informed by the Apache-2.0 licensed `googlecreativelab/teachablemachine-community` source. Modified and newly written files in this distribution carry this notice and are distributed under Apache-2.0.

The optional Abnormal Sound feature extractor reconstructs the Apache-2.0 licensed YAMNet
MobileNetV1 topology and frontend constants from `tensorflow/models`, and uses the official
YAMNet HDF5 weights downloaded from Google Storage. Local Studio verifies the pinned weight
SHA-256 before use. TensorFlow and YAMNet remain projects of their respective authors; this
distribution is not an official Google product.
